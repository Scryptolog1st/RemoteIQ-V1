# RemoteIQ - Frontend

This repository contains the frontend application for RemoteIQ, a next-generation Remote Monitoring & Management (RMM) platform.

## Phase F0: Scaffold & Hardening

This initial commit establishes the foundational scaffold for the project.

### Tech Stack

* **Framework:** [Next.js 15](https://nextjs.org/) (App Router)
* **Language:** [TypeScript](https://www.typescriptlang.org/)
* **Styling:** [Tailwind CSS](https://tailwindcss.com/)
* **UI Components:** [shadcn/ui](https://ui.shadcn.com/)
* **Linting:** [ESLint](https://eslint.org/)
* **Formatting:** [Prettier](https://prettier.io/)
* **Package Manager:** [pnpm](https://pnpm.io/)

### Getting Started

1.  **Install Dependencies:**
    ```bash
    pnpm install
    ```

2.  **Run the Development Server:**
    ```bash
    pnpm dev
    ```

    Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

### Scripts

* `pnpm dev`: Starts the development server.
* `pnpm build`: Creates a production build.
* `pnpm start`: Starts the production server.
* `pnpm lint`: Runs ESLint to check for code quality issues.

### Definition of Done (DoD) Checklist - F0

- [x] App Router scaffold initialized.
- [x] TypeScript configured with strict mode and path aliases.
- [x] Tailwind CSS and `shadcn/ui` configured.
- [x] Design tokens foundation laid in `tailwind.config.ts`.
- [x] Global layout with `ThemeProvider` for dark/light modes established.
- [x] Base accessibility standards considered in root layout.
- [x] ESLint and Prettier configured for code quality.
- [x] CI-ready scripts (`lint`, `build`) are present in `package.json`.
