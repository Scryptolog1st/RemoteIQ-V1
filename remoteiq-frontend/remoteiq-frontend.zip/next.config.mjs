/** @type {import('next').NextConfig} */
const nextConfig = {
  // Add any Next.js specific configurations here in the future.
  // For F0, the default configuration is sufficient.
};

export default nextConfig;
