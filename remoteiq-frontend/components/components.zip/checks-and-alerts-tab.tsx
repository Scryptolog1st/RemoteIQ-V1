"use client"

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react'

type CheckStatus = 'Passing' | 'Failing' | 'Warning'

interface Check {
    id: string;
    name: string;
    status: CheckStatus;
    lastRun: string;
    output: string;
}

const mockChecks: Check[] = [
    { id: '1', name: 'Ping Check', status: 'Passing', lastRun: '2 minutes ago', output: 'Reply from 8.8.8.8: bytes=32 time=12ms TTL=117' },
    { id: '2', name: 'Disk Space (C:)', status: 'Passing', lastRun: '5 minutes ago', output: '75% free (375GB / 500GB)' },
    { id: '3', name: 'CPU Load', status: 'Warning', lastRun: '1 minute ago', output: 'CPU usage at 85% for 5 minutes' },
    { id: '4', name: 'Windows Service: Spooler', status: 'Passing', lastRun: '10 minutes ago', output: 'Service is running' },
    { id: '5', name: 'Antivirus Definition Check', status: 'Failing', lastRun: '1 hour ago', output: 'Virus definitions are more than 7 days out of date' },
];

const StatusIcon = ({ status }: { status: CheckStatus }) => {
    switch (status) {
        case 'Passing':
            return <CheckCircle2 className="h-5 w-5 text-status-healthy" />
        case 'Failing':
            return <XCircle className="h-5 w-5 text-status-critical" />
        case 'Warning':
            return <AlertTriangle className="h-5 w-5 text-status-warning" />
        default:
            return null
    }
}


export default function ChecksAndAlertsTab() {
    const failingChecks = mockChecks.filter(c => c.status === 'Failing').length;
    const warningChecks = mockChecks.filter(c => c.status === 'Warning').length;

    return (
        <div className="grid gap-6">
            <div className="grid md:grid-cols-2 gap-6">
                <Card>
                    <CardHeader>
                        <CardTitle>Active Alerts</CardTitle>
                        <CardDescription>A summary of checks that require attention.</CardDescription>
                    </CardHeader>
                    <CardContent className="grid gap-4">
                        <div className="flex items-center justify-between p-4 bg-status-critical/10 rounded-lg">
                            <div className="flex items-center gap-4">
                                <XCircle className="h-8 w-8 text-status-critical" />
                                <div>
                                    <p className="font-semibold">{failingChecks} Failing Check{failingChecks !== 1 && 's'}</p>
                                    <p className="text-sm text-muted-foreground">Immediate attention required.</p>
                                </div>
                            </div>
                            <Badge variant="destructive">{failingChecks}</Badge>
                        </div>
                        <div className="flex items-center justify-between p-4 bg-status-warning/10 rounded-lg">
                            <div className="flex items-center gap-4">
                                <AlertTriangle className="h-8 w-8 text-status-warning" />
                                <div>
                                    <p className="font-semibold">{warningChecks} Warning Check{warningChecks !== 1 && 's'}</p>
                                    <p className="text-sm text-muted-foreground">Potential issues detected.</p>
                                </div>
                            </div>
                            <Badge variant="secondary" className="bg-status-warning/80 text-black">{warningChecks}</Badge>
                        </div>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Checks Summary</CardTitle>
                        <CardDescription>Overview of all monitored checks on this device.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        {/* Placeholder for future summary charts or info */}
                        <div className="flex items-center justify-center h-full text-muted-foreground">
                            <p>Summary components coming soon.</p>
                        </div>
                    </CardContent>
                </Card>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle>Check History</CardTitle>
                    <CardDescription>A log of the most recent check results.</CardDescription>
                </CardHeader>
                <CardContent>
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead className="w-[50px]"></TableHead>
                                <TableHead>Check Name</TableHead>
                                <TableHead>Last Run</TableHead>
                                <TableHead>Output</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {mockChecks.map((check) => (
                                <TableRow key={check.id}>
                                    <TableCell><StatusIcon status={check.status} /></TableCell>
                                    <TableCell className="font-medium">{check.name}</TableCell>
                                    <TableCell>{check.lastRun}</TableCell>
                                    <TableCell className="text-muted-foreground">{check.output}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </CardContent>
            </Card>
        </div>
    )
}
