"use client"

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Search } from 'lucide-react';

export interface Script {
    id: string;
    name: string;
    description: string;
    language: 'PowerShell' | 'Bash';
    version: string;
}

const mockScripts: Script[] = [
    { id: '1', name: 'Install Chocolatey', description: 'Installs the Chocolatey package manager on Windows.', language: 'PowerShell', version: '1.2.0' },
    { id: '2', name: 'Update System Packages (APT)', description: 'Runs apt-get update and apt-get upgrade on Debian/Ubuntu.', language: 'Bash', version: '1.0.1' },
    { id: '3', name: 'Disable Windows Firewall', description: 'Turns off the Windows Defender Firewall for all profiles.', language: 'PowerShell', version: '1.1.0' },
    { id: '4', name: 'Check Disk Space', description: 'Reports the available disk space on all mounted volumes.', language: 'Bash', version: '1.3.0' },
    { id: '5', name: 'Force GPUpdate', description: 'Forces a Group Policy update on a Windows machine.', language: 'PowerShell', version: '1.0.0' },
];

interface WizardStep2Props {
    selectedScript: Script | null;
    setSelectedScript: (script: Script) => void;
}

export default function WizardStep2({ selectedScript, setSelectedScript }: WizardStep2Props) {
    const [searchTerm, setSearchTerm] = React.useState('');

    const filteredScripts = mockScripts.filter(script =>
        script.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        script.description.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const languageColorMap = {
        'PowerShell': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
        'Bash': 'bg-gray-500/20 text-gray-400 border-gray-500/30'
    };

    return (
        <div className="flex flex-col h-full">
            <div className="relative mb-4">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                    placeholder="Search scripts..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                />
            </div>
            <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                {filteredScripts.map(script => (
                    <Card
                        key={script.id}
                        className={cn(
                            "cursor-pointer transition-all hover:border-primary",
                            selectedScript?.id === script.id && 'border-primary ring-2 ring-primary'
                        )}
                        onClick={() => setSelectedScript(script)}
                    >
                        <CardHeader>
                            <div className="flex justify-between items-start">
                                <div>
                                    <CardTitle className="text-lg">{script.name}</CardTitle>
                                    <CardDescription>{script.description}</CardDescription>
                                </div>
                                <Badge variant="outline" className={cn(languageColorMap[script.language])}>
                                    {script.language}
                                </Badge>
                            </div>
                        </CardHeader>
                        <CardContent>
                            <p className="text-xs text-muted-foreground">Version: {script.version}</p>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>
    )
}
