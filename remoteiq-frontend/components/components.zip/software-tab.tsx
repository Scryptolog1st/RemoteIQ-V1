"use client"

import React from "react"
import { ColumnDef, SortingState, ColumnFiltersState, VisibilityState } from "@tanstack/react-table"
import { ArrowUpDown, MoreHorizontal } from "lucide-react"
import { DataTable } from '@/components/data-table'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

// --- Type and Mock Data ---
export type Software = {
    id: string
    name: string
    version: string
    publisher: string
    installDate: string
}

const mockSoftware: Software[] = [
    { id: "1", name: "Google Chrome", version: "125.0.6422.112", publisher: "Google LLC", installDate: "2023-01-15" },
    { id: "2", name: "Microsoft Visual Studio Code", version: "1.89.1", publisher: "Microsoft Corporation", installDate: "2023-02-20" },
    { id: "3", name: "Git", version: "2.43.0", publisher: "The Git Development Community", installDate: "2023-01-10" },
    { id: "4", name: "Node.js", version: "20.11.1", publisher: "Node.js Foundation", installDate: "2023-03-01" },
];

// --- Column Definitions ---
export const columns: ColumnDef<Software>[] = [
    {
        accessorKey: "name",
        header: ({ column }) => (
            <Button variant="ghost" onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}>
                Name <ArrowUpDown className="ml-2 h-4 w-4" />
            </Button>
        ),
    },
    {
        accessorKey: "version",
        header: "Version",
    },
    {
        accessorKey: "publisher",
        header: "Publisher",
    },
    {
        accessorKey: "installDate",
        header: "Install Date",
    },
    {
        id: "actions",
        cell: () => (
            <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
            </Button>
        ),
    },
]

// --- Main Component ---
export default function SoftwareTab() {
    const [sorting, setSorting] = React.useState<SortingState>([])
    const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>([])
    const [columnVisibility, setColumnVisibility] = React.useState<VisibilityState>({})

    return (
        <Card>
            <CardContent className="pt-6">
                <DataTable
                    columns={columns}
                    data={mockSoftware}
                    sorting={sorting}
                    setSorting={setSorting}
                    columnFilters={columnFilters}
                    setColumnFilters={setColumnFilters}
                    columnVisibility={columnVisibility}
                    setColumnVisibility={setColumnVisibility}
                    filterColumn="name"
                    filterInputPlaceholder="Filter by name..."
                />
            </CardContent>
        </Card>
    )
}

