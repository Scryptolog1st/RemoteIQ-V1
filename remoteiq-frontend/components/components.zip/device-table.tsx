"use client";

import React from "react";
import { DataTable } from "@/components/data-table";
import { columns } from "@/components/device-table-columns";
import { useDashboard } from "@/app/(dashboard)/dashboard-context";

export default function DeviceTable() {
    const {
        filteredDevices,
        columnVisibility,
        setColumnVisibility,
        sorting,
        setSorting,
        columnFilters,
        setColumnFilters,
    } = useDashboard();

    return (
        <DataTable
            columns={columns}
            data={filteredDevices}
            columnVisibility={columnVisibility}
            setColumnVisibility={setColumnVisibility}
            sorting={sorting}
            setSorting={setSorting}
            columnFilters={columnFilters}
            setColumnFilters={setColumnFilters}
            filterColumn="hostname"
            filterInputPlaceholder="Filter by hostname..."
        />
    );
}
