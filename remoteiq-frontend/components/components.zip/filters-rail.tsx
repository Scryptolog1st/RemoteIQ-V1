"use client";

import * as React from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
    useDashboard,
    type ActiveFilters,
    type DeviceStatus,
} from "@/app/(dashboard)/dashboard-context";

const STATUS_OPTIONS: DeviceStatus[] = ["Healthy", "Warning", "Critical", "Offline"];

export default function FiltersRail() {
    const { activeFilters, setActiveFilters, operatingSystems } = useDashboard();

    // Computed: do we have any active filters?
    const hasActiveFilters =
        (activeFilters.status?.length ?? 0) > 0 ||
        (activeFilters.os?.length ?? 0) > 0;

    // Local popover state so the confirm appears right under the Clear button
    const [confirmOpen, setConfirmOpen] = React.useState(false);

    // Keep popover closed if nothing is active (and close if state changes to inactive)
    React.useEffect(() => {
        if (!hasActiveFilters && confirmOpen) setConfirmOpen(false);
    }, [hasActiveFilters, confirmOpen]);

    // --- handlers -----------------------------------------------------

    const onToggleStatus = (value: DeviceStatus, checked: boolean | "indeterminate") => {
        setActiveFilters((prev: ActiveFilters) => {
            const next = new Set(prev.status);
            checked ? next.add(value) : next.delete(value);
            return { ...prev, status: Array.from(next) };
        });
    };

    const onToggleOs = (
        value: (typeof operatingSystems)[number],
        checked: boolean | "indeterminate"
    ) => {
        setActiveFilters((prev: ActiveFilters) => {
            const next = new Set(prev.os);
            checked ? next.add(value) : next.delete(value);
            return { ...prev, os: Array.from(next) };
        });
    };

    const clearAll = () => {
        setActiveFilters({ status: [], os: [] });
        setConfirmOpen(false);
    };

    // --- UI -----------------------------------------------------------

    return (
        <aside className="space-y-6">
            <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold">Filters</h3>

                {/* Anchored destructive confirm directly under the button */}
                <Popover open={confirmOpen} onOpenChange={(o) => hasActiveFilters && setConfirmOpen(o)}>
                    <PopoverTrigger asChild>
                        <Button
                            variant="destructive"
                            size="sm"
                            aria-label="Clear all filters"
                            title="Clear all filters"
                            disabled={!hasActiveFilters}
                        >
                            Clear All
                        </Button>
                    </PopoverTrigger>
                    <PopoverContent side="bottom" align="end" sideOffset={8} className="w-72 p-4">
                        <div className="space-y-2">
                            <p className="text-sm font-medium">Clear all filters?</p>
                            <p className="text-xs text-muted-foreground">
                                This will remove all selected <b>Status</b> and <b>Operating System</b> filters.
                            </p>
                            <div className="mt-3 flex justify-end gap-2">
                                <Button variant="outline" size="sm" onClick={() => setConfirmOpen(false)} title="Cancel">
                                    Cancel
                                </Button>
                                <Button variant="destructive" size="sm" onClick={clearAll} title="Confirm clear">
                                    Clear All
                                </Button>
                            </div>
                        </div>
                    </PopoverContent>
                </Popover>
            </div>

            {/* Status */}
            <section className="space-y-3">
                <h4 className="text-xs font-medium text-muted-foreground">Status</h4>
                <div className="grid gap-2">
                    {STATUS_OPTIONS.map((s) => {
                        const checked = activeFilters.status?.includes(s) ?? false;
                        const id = `status-${s}`;
                        return (
                            <div key={s} className="flex items-center gap-2">
                                <Checkbox
                                    id={id}
                                    checked={checked}
                                    onCheckedChange={(v) => onToggleStatus(s, v)}
                                    aria-checked={checked}
                                />
                                <Label htmlFor={id}>{s}</Label>
                            </div>
                        );
                    })}
                </div>
            </section>

            {/* Operating System */}
            <section className="space-y-3">
                <h4 className="text-xs font-medium text-muted-foreground">Operating System</h4>
                <div className="grid gap-2">
                    {operatingSystems.map((os) => {
                        const checked = activeFilters.os?.includes(os) ?? false;
                        const id = `os-${os}`;
                        return (
                            <div key={os} className="flex items-center gap-2">
                                <Checkbox
                                    id={id}
                                    checked={checked}
                                    onCheckedChange={(v) => onToggleOs(os, v)}
                                    aria-checked={checked}
                                />
                                <Label htmlFor={id}>{os}</Label>
                            </div>
                        );
                    })}
                </div>
            </section>
        </aside>
    );
}
