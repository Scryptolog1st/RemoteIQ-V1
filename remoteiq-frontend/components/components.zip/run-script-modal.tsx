"use client";

import * as React from "react";
import {
    Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
    Select, SelectTrigger, SelectContent, SelectItem, SelectValue
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { X } from "lucide-react";
import { cn } from "@/lib/utils";

import { useDashboard, type Device } from "@/app/(dashboard)/dashboard-context";
import { DataTable } from "@/components/data-table";
import { columns as deviceColumns } from "@/components/device-table-columns";
import type {
    ColumnFiltersState, RowSelectionState, SortingState, VisibilityState, ColumnDef
} from "@tanstack/react-table";

type TargetScope = "client" | "site" | "selected" | "all";
type AgentOS = "windows" | "linux" | "macos" | "all";
type AgentType = "all" | "servers" | "workstations";

export type RunScriptPayload = {
    target: TargetScope;
    clientId?: string | null;
    siteId?: string | null;
    os: AgentOS;
    agentType: AgentType;
    scriptId?: string | null;
    args: string[];
    env: Record<string, string>;
    runAsUser: boolean;
    saveToCustomField: boolean;
    saveToAgentNote: boolean;
    timeoutSec: number;
    selectedDeviceIds?: string[];
};

type RunScriptModalProps = {
    open: boolean;
    onOpenChange: (open: boolean) => void;
    onRun?: (payload: RunScriptPayload) => Promise<void> | void;

    clients?: Array<{ id: string; name: string }>;
    sitesByClient?: Record<string, Array<{ id: string; name: string }>>;
    scripts?: Array<{ id: string; name: string }>;

    /** When provided, the modal switches to "Selected Agents", opens the panel, and pre-checks these devices. */
    preselectDeviceIds?: string[] | undefined;
};

export default function RunScriptModal({
    open, onOpenChange, onRun,
    clients = [
        { id: "c1", name: "Global Corp" },
        { id: "c2", name: "Innovate LLC" },
    ],
    sitesByClient = {
        c1: [
            { id: "c1-hq", name: "Headquarters" },
            { id: "c1-branch", name: "Branch Office" },
        ],
        c2: [{ id: "c2-main", name: "Main Campus" }],
    },
    scripts = [
        { id: "s1", name: "Restart Service" },
        { id: "s2", name: "Update Windows" },
        { id: "s3", name: "Collect Logs" },
    ],
    preselectDeviceIds,
}: RunScriptModalProps) {
    const {
        masterDevices, filteredDevices,
        columnVisibility, setColumnVisibility,
        sorting, setSorting,
        columnFilters, setColumnFilters,
    } = useDashboard();

    const [rowSelection, setRowSelection] = React.useState<RowSelectionState>({});
    const [target, setTarget] = React.useState<TargetScope>("client");
    const [clientId, setClientId] = React.useState<string | undefined>();
    const [siteId, setSiteId] = React.useState<string | undefined>();
    const [os, setOs] = React.useState<AgentOS>("windows");
    const [agentType, setAgentType] = React.useState<AgentType>("all");
    const [scriptId, setScriptId] = React.useState<string | undefined>();

    const [args, setArgs] = React.useState<string[]>([]);
    const [argDraft, setArgDraft] = React.useState("");

    const [env, setEnv] = React.useState<Record<string, string>>({});
    const [envKeyDraft, setEnvKeyDraft] = React.useState("");
    const [envValDraft, setEnvValDraft] = React.useState("");

    const [endpointsOpen, setEndpointsOpen] = React.useState(false);

    React.useEffect(() => setSiteId(undefined), [clientId]);
    React.useEffect(() => { if (target !== "selected") setRowSelection({}); }, [target]);

    // Bootstrap preselection (prop first; otherwise from URL ?device= or ?runScript=)
    React.useEffect(() => {
        if (!open) return;

        const idsFromProp = preselectDeviceIds && preselectDeviceIds.length ? preselectDeviceIds : null;

        let idsFromUrl: string[] | null = null;
        try {
            const url = new URL(window.location.href);
            const d = url.searchParams.get("device");
            const r = url.searchParams.get("runScript");
            if (d) idsFromUrl = [d];
            else if (r) idsFromUrl = [r];
        } catch { }

        const ids = idsFromProp ?? idsFromUrl;
        if (ids && ids.length) {
            setTarget("selected");
            setEndpointsOpen(true);
            const map: RowSelectionState = {};
            ids.forEach((id) => { map[id] = true; });
            setRowSelection(map);
        }
    }, [open, preselectDeviceIds]);

    const allDevices: Device[] = React.useMemo(
        () => (masterDevices?.length ? masterDevices : filteredDevices),
        [masterDevices, filteredDevices]
    );

    const modalDevices: Device[] = React.useMemo(() => {
        if (target === "client" && clientId) {
            const clientName = clients.find((c) => c.id === clientId)?.name;
            if (!clientName) return allDevices;
            return allDevices.filter((d) => d.client === clientName);
        }
        if (target === "site" && clientId && siteId) {
            const clientName = clients.find((c) => c.id === clientId)?.name;
            const siteName = (sitesByClient[clientId] || []).find((s) => s.id === siteId)?.name;
            if (!clientName || !siteName) return allDevices;
            return allDevices.filter((d) => d.client === clientName && d.site === siteName);
        }
        return allDevices;
    }, [target, clientId, siteId, allDevices, clients, sitesByClient]);

    const selectedDeviceIds = React.useMemo(() => {
        if (!rowSelection) return [];
        return Object.keys(rowSelection).filter((k) => (rowSelection as any)[k]);
    }, [rowSelection]);

    const removeEnvKey = (k: string) => {
        setEnv((prev) => {
            const next = { ...prev };
            delete next[k];
            return next;
        });
    };

    const handleRun = async () => {
        const payload: RunScriptPayload = {
            target,
            clientId: target === "client" || target === "site" ? clientId ?? null : null,
            siteId: target === "site" ? siteId ?? null : null,
            os,
            agentType,
            scriptId: scriptId ?? null,
            args,
            env,
            runAsUser: false,
            saveToCustomField: false,
            saveToAgentNote: false,
            timeoutSec: 30,
            selectedDeviceIds: target === "selected" ? selectedDeviceIds : undefined,
        };
        await onRun?.(payload);
        onOpenChange(false);
    };

    // Wider, responsive modal when endpoint panel is open
    const dialogWidthClass = endpointsOpen ? "max-w-[2300px]" : "max-w-[1200px]";
    const rightInteractive = endpointsOpen ? "" : "pointer-events-none";

    // selection column (narrow)
    const selectColumn = React.useMemo<ColumnDef<Device, unknown>>(
        () => ({
            id: "select",
            header: ({ table }) => {
                const allPageSelected = table.getIsAllPageRowsSelected();
                const somePageSelected = table.getIsSomePageRowsSelected();
                return (
                    <div className="flex items-center justify-center">
                        <Checkbox
                            aria-label="Select all rows on this page"
                            className="h-4 w-4"
                            checked={allPageSelected || (somePageSelected ? "indeterminate" : false)}
                            onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
                        />
                    </div>
                );
            },
            cell: ({ row }) => (
                <div className="flex items-center justify-center">
                    <Checkbox
                        aria-label={`Select ${row.original.hostname}`}
                        className="h-4 w-4"
                        checked={row.getIsSelected()}
                        onCheckedChange={(value) => row.toggleSelected(!!value)}
                    />
                </div>
            ),
            enableHiding: false,
            enableSorting: false,
            meta: {
                headerClassName: "w-8 px-0",
                cellClassName: "w-8 px-0",
            } as any,
        }),
        []
    );

    const endpointColumns = React.useMemo(() => {
        const base = (deviceColumns as ColumnDef<Device, unknown>[]).filter((col) => (col as any).id !== "actions");
        return [selectColumn, ...base];
    }, [selectColumn]);

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent
                className={cn(
                    "w-[99vw] h-[80vh] max-h-[80vh] transition-[max-width,width] duration-300 ease-in-out overflow-hidden",
                    dialogWidthClass
                )}
            >
                <div className="flex h-full">
                    {/* LEFT */}
                    <div className="flex-1 min-w-0 pr-4 flex flex-col">
                        <DialogHeader className="shrink-0">
                            <DialogTitle>Run Bulk Script</DialogTitle>
                            <DialogDescription>
                                Choose targets, OS/type, script, and options. Open the endpoint panel to pick specific devices.
                            </DialogDescription>
                        </DialogHeader>

                        <div className="flex-1 overflow-y-auto mt-4 space-y-6">
                            {/* Choose target */}
                            <section className="space-y-3">
                                <div className="flex items-center justify-between">
                                    <h3 className="text-sm font-semibold">Choose Target</h3>
                                    <div className="flex items-center gap-2">
                                        <Button
                                            type="button"
                                            variant="outline"
                                            size="sm"
                                            onClick={() => setEndpointsOpen((p) => !p)}
                                        >
                                            {endpointsOpen ? "Close Endpoint Panel" : "Open Endpoint Panel"}
                                        </Button>
                                        {target === "selected" && (
                                            <span className="text-xs text-muted-foreground">
                                                Selected: <span className="font-medium">{selectedDeviceIds.length}</span>
                                            </span>
                                        )}
                                    </div>
                                </div>

                                <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                                    <RadioTile label="Client" checked={target === "client"} onChange={() => setTarget("client")} />
                                    <RadioTile label="Site" checked={target === "site"} onChange={() => setTarget("site")} />
                                    <RadioTile label="Selected Agents" checked={target === "selected"} onChange={() => setTarget("selected")} />
                                    <RadioTile label="All" checked={target === "all"} onChange={() => setTarget("all")} />
                                </div>

                                {(target === "client" || target === "site") && (
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <div className="space-y-1.5">
                                            <Label>Select Client</Label>
                                            <Select value={clientId} onValueChange={(v) => setClientId(v)}>
                                                <SelectTrigger><SelectValue placeholder="Choose a client" /></SelectTrigger>
                                                <SelectContent>
                                                    {clients.map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        {target === "site" && (
                                            <div className="space-y-1.5">
                                                <Label>Select Site</Label>
                                                <Select value={siteId} onValueChange={(v) => setSiteId(v)} disabled={!clientId}>
                                                    <SelectTrigger><SelectValue placeholder="Choose a site" /></SelectTrigger>
                                                    <SelectContent>
                                                        {(clientId ? sitesByClient[clientId] : [])?.map((s) => (
                                                            <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        )}
                                    </div>
                                )}
                            </section>

                            {/* OS + Type */}
                            <section className="grid gap-6 md:grid-cols-2">
                                <div className="space-y-2">
                                    <h3 className="text-sm font-semibold">Agent OS</h3>
                                    <RadioGroup value={os} onValueChange={(v: AgentOS) => setOs(v)} className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                                        <RadioOption id="os-win" value="windows" label="Windows" />
                                        <RadioOption id="os-linux" value="linux" label="Linux" />
                                        <RadioOption id="os-mac" value="macOS" label="macOS" />
                                        <RadioOption id="os-all" value="all" label="All" />
                                    </RadioGroup>
                                </div>

                                <div className="space-y-2">
                                    <h3 className="text-sm font-semibold">Agent Type</h3>
                                    <RadioGroup value={agentType} onValueChange={(v: AgentType) => setAgentType(v)} className="grid grid-cols-3 gap-3">
                                        <RadioOption id="type-all" value="all" label="All" />
                                        <RadioOption id="type-servers" value="servers" label="Servers" />
                                        <RadioOption id="type-workstations" value="workstations" label="Workstations" />
                                    </RadioGroup>
                                </div>
                            </section>

                            {/* Script select */}
                            <section className="space-y-2">
                                <h3 className="text-sm font-semibold">Select Script</h3>
                                <Select value={scriptId} onValueChange={(v) => setScriptId(v)}>
                                    <SelectTrigger><SelectValue placeholder="Choose a script" /></SelectTrigger>
                                    <SelectContent>
                                        {scripts.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                                    </SelectContent>
                                </Select>
                            </section>

                            {/* Args + Env */}
                            <section className="grid gap-6 md:grid-cols-2">
                                <div className="space-y-2">
                                    <h3 className="text-sm font-semibold">
                                        Script Arguments <span className="text-muted-foreground font-normal">(press Enter to add)</span>
                                    </h3>
                                    <Input
                                        placeholder="Type an argument and press Enter"
                                        value={argDraft}
                                        onChange={(e) => setArgDraft(e.target.value)}
                                        onKeyDown={(e) => {
                                            if (e.key === "Enter") {
                                                e.preventDefault();
                                                const v = argDraft.trim();
                                                if (v) { setArgs((prev) => [...prev, v]); setArgDraft(""); }
                                            }
                                        }}
                                    />
                                    <ChipList items={args} onRemove={(i) => setArgs((p) => p.filter((_, idx) => idx !== i))} />
                                </div>

                                <div className="space-y-2">
                                    <h3 className="text-sm font-semibold">
                                        Environment vars <span className="text-muted-foreground font-normal">(Enter adds)</span>
                                    </h3>
                                    <div className="grid grid-cols-2 gap-2">
                                        <Input
                                            placeholder="KEY"
                                            value={envKeyDraft}
                                            onChange={(e) => setEnvKeyDraft(e.target.value)}
                                            onKeyDown={(e) => {
                                                if (e.key === "Enter") {
                                                    e.preventDefault();
                                                    const k = envKeyDraft.trim();
                                                    const v = envValDraft.trim();
                                                    if (k) { setEnv((prev) => ({ ...prev, [k]: v })); setEnvKeyDraft(""); setEnvValDraft(""); }
                                                }
                                            }}
                                        />
                                        <Input
                                            placeholder="value"
                                            value={envValDraft}
                                            onChange={(e) => setEnvValDraft(e.target.value)}
                                            onKeyDown={(e) => {
                                                if (e.key === "Enter") {
                                                    e.preventDefault();
                                                    const k = envKeyDraft.trim();
                                                    const v = envValDraft.trim();
                                                    if (k) { setEnv((prev) => ({ ...prev, [k]: v })); setEnvKeyDraft(""); setEnvValDraft(""); }
                                                }
                                            }}
                                        />
                                    </div>
                                    <div className="flex flex-wrap gap-2">
                                        {Object.entries(env).map(([k, v]) => (
                                            <span key={k} className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs">
                                                <code className="font-mono">{k}={v}</code>
                                                <button onClick={() => removeEnvKey(k)} className="hover:text-destructive">
                                                    <X className="h-3.5 w-3.5" />
                                                </button>
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            </section>
                        </div>

                        {/* Footer */}
                        {/* Footer */}
                        <div className="shrink-0 pt-3">
                            <div className="flex justify-end gap-2 border-t pt-3">
                                <Button variant="outline" onClick={() => onOpenChange(false)} title="Cancel">
                                    Cancel
                                </Button>
                                <Button
                                    type="submit"
                                    onClick={handleRun}
                                    disabled={target === "selected" && selectedDeviceIds.length === 0}
                                    title="Run script"
                                    className={cn(
                                        "bg-emerald-600 text-white hover:bg-emerald-500 active:bg-emerald-600",
                                        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400 focus-visible:ring-offset-2 focus-visible:ring-offset-background",
                                        "shadow-sm hover:shadow transition duration-150",
                                        "disabled:bg-muted disabled:text-muted-foreground disabled:opacity-70 disabled:cursor-not-allowed"
                                    )}
                                >
                                    Run
                                </Button>

                            </div>
                        </div>

                    </div>

                    {/* RIGHT: endpoints panel */}
                    <div
                        className={cn(
                            "shrink-0 border-l transition-all duration-300 ease-in-out h-full",
                            rightInteractive
                        )}
                        aria-label="Endpoints panel"
                        /* Responsive width: min(50vw, 1200px); closed = 0 */
                        style={{
                            width: endpointsOpen ? "min(50vw, 1200px)" : 0,
                            opacity: endpointsOpen ? 1 : 0,
                        }}
                    >
                        <div className="h-full flex flex-col">
                            <div className="px-4 pt-4 pb-3 border-b">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h2 className="text-base font-semibold">Endpoints</h2>
                                        <p className="text-xs text-muted-foreground mt-1">
                                            {target === "selected" ? (
                                                <>Selected: <span className="font-medium">{selectedDeviceIds.length}</span></>
                                            ) : (
                                                <>Tip: choose <span className="font-medium">Selected Agents</span> to target specific endpoints</>
                                            )}
                                        </p>
                                    </div>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => setRowSelection({})}
                                        disabled={selectedDeviceIds.length === 0}
                                    >
                                        Clear
                                    </Button>
                                </div>
                            </div>

                            {/* No horizontal scroll; shrink-to-fit */}
                            <div className="overflow-x-hidden">
                                <div className="min-w-0">
                                    <DataTable<Device, unknown>
                                        columns={endpointColumns}
                                        data={modalDevices}
                                        sorting={sorting as SortingState}
                                        setSorting={setSorting}
                                        columnVisibility={columnVisibility as VisibilityState}
                                        setColumnVisibility={setColumnVisibility}
                                        columnFilters={columnFilters as ColumnFiltersState}
                                        setColumnFilters={setColumnFilters}
                                        filterColumn="hostname"
                                        filterInputPlaceholder="Filter by hostname…"
                                        rowSelection={rowSelection}
                                        setRowSelection={setRowSelection}
                                        compact
                                    />
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
}

/* ---------- helpers ---------- */
function RadioTile({ label, checked, onChange }: { label: string; checked?: boolean; onChange?: () => void; }) {
    return (
        <button
            type="button"
            onClick={onChange}
            className={cn("rounded-md border px-3 py-2 text-left text-sm", checked ? "border-primary ring-2 ring-primary/30" : "hover:bg-accent")}
            aria-pressed={checked}
        >
            {label}
        </button>
    );
}

function RadioOption({ id, value, label }: { id: string; value: string; label: string; }) {
    return (
        <div className="flex items-center space-x-2">
            <RadioGroupItem id={id} value={value} />
            <Label htmlFor={id}>{label}</Label>
        </div>
    );
}

function ChipList({ items, onRemove }: { items: string[]; onRemove: (idx: number) => void; }) {
    if (!items.length) return null;
    return (
        <div className="flex flex-wrap gap-2">
            {items.map((v, i) => (
                <span key={`${v}-${i}`} className="inline-flex items-center gap-2 rounded-full bg-muted px-3 py-1 text-xs">
                    <code className="font-mono">{v}</code>
                    <button onClick={() => onRemove(i)} className="hover:text-destructive">
                        <X className="h-3.5 w-3.5" />
                    </button>
                </span>
            ))}
        </div>
    );
}
