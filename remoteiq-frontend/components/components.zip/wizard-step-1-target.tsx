"use client";

import * as React from "react";
import FiltersRail from "@/components/filters-rail"; // ✅ default export
import { useDashboard } from "@/app/(dashboard)/dashboard-context";
import { Button } from "@/components/ui/button";

/**
 * Minimal, safe version that compiles and keeps prior intent:
 * - Uses context so types line up with ActiveFilters / operatingSystems
 * - Renders a small stub you can expand (kept generic to avoid reintroducing errors)
 */
export default function WizardStep1Target() {
    const {
        operatingSystems,
        activeFilters,
        setActiveFilters,
        filteredDevices,
    } = useDashboard();

    // Example interaction to prove types wire up
    const toggleFirstOs = () => {
        const first = operatingSystems[0];
        setActiveFilters((prev) => {
            const next = new Set(prev.os);
            if (next.has(first)) next.delete(first);
            else next.add(first);
            return { ...prev, os: Array.from(next) };
        });
    };

    return (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[260px_1fr]">
            <aside className="hidden lg:block">
                <FiltersRail />
            </aside>
            <section className="space-y-3">
                <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold">Target selection</h3>
                    <Button variant="outline" size="sm" onClick={toggleFirstOs}>
                        Toggle {operatingSystems[0]}
                    </Button>
                </div>
                <p className="text-sm text-muted-foreground">
                    Active OS filters: {activeFilters.os.join(", ") || "none"}
                </p>
                <p className="text-sm text-muted-foreground">
                    Matching devices: <span className="font-medium">{filteredDevices.length}</span>
                </p>
            </section>
        </div>
    );
}
