"use client";

import * as React from "react";
import {
    Card,
    CardHeader,
    CardTitle,
    CardDescription,
    CardContent,
} from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
    Select,
    SelectTrigger,
    SelectContent,
    SelectItem,
    SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
    DialogFooter,
} from "@/components/ui/dialog";
import {
    Shield,
    ShieldCheck,
    Users,
    UserPlus,
    Trash2,
    Search,
    KeyRound,
    ServerCog,
    ActivitySquare,
    FileText,
    Lock,
    Bug,
    Rocket,
    Bell,
    Mail,
    Globe,
    Wrench,
    Plus,
    Settings,
    Trash,
    TestTube2,
    Database as DbIcon,
    Cloud,
    ArchiveRestore,
    FileSignature,
    Building2,
    CreditCard,
    ReceiptText,
    Landmark,
    Palette,
    Languages,
    BellRing,
    LockKeyhole,
    Gavel,
    Plug,
    Laptop2,
    Workflow,
    ArrowRightLeft,
    ListPlus,
    Gem,
    UserCog,
    Ticket,
    Vault,
    Table,
    DatabaseZap,
    BarChart3,
    BookUser,
    Columns,
    CalendarClock,
    ShieldAlert,
    BookKey,
    UserCheck,
    Download,
    Upload,
    Slack,
} from "lucide-react";
import { cn } from "@/lib/utils";

/** ===== lightweight toasts (bottom-right) ===== */
type ToastKind = "success" | "destructive" | "warning" | "default";
type Toast = { id: string; title: string; desc?: string; kind: ToastKind };

function useToasts() {
    const [toasts, setToasts] = React.useState<Toast[]>([]);
    const push = React.useCallback((t: Omit<Toast, "id">) => {
        const id = Math.random().toString(36).slice(2);
        setToasts((prev) => [...prev, { ...t, id }]);
        window.setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4200);
    }, []);
    return { toasts, push };
}

/** ===== Types ===== */
type PermissionKey =
    | "view_devices"
    | "manage_devices"
    | "manage_users"
    | "billing_access"
    | "view_audit"
    | "manage_api"
    | "manage_flags";

type Role = {
    id: string;
    name: string;
    permissions: Record<PermissionKey, boolean>;
    builtIn?: boolean;
};

type EmailPurpose = "alerts" | "invites" | "password_resets" | "reports";

type SmtpSettings = {
    host: string;
    port: number | "";
    username: string;
    password: string;
    useTLS: boolean;
    useSSL: boolean;
    fromAddress: string;
};

type ImapSettings = {
    host: string;
    port: number | "";
    username: string;
    password: string;
    useSSL: boolean;
};

type PopSettings = {
    host: string;
    port: number | "";
    username: string;
    password: string;
    useSSL: boolean;
};

type EmailProfile = {
    smtp: SmtpSettings;
    imap: ImapSettings;
    pop: PopSettings;
    enabled: boolean;
};

/* ===== Audit types ===== */
type AuditCategory = "security" | "role" | "user" | "auth" | "email" | "device" | "system";
type AuditSeverity = "info" | "warning" | "error";
type AuditLog = {
    id: string;
    at: string;
    category: AuditCategory;
    severity: AuditSeverity;
    actor: string;
    action: string;
    details?: string;
};

/* ===== API tab types ===== */
type ApiKeyScope =
    | "read:devices"
    | "write:devices"
    | "read:users"
    | "write:users"
    | "read:audit"
    | "admin:roles"
    | "admin:flags";

type ApiKeyRow = {
    id: string;
    label: string;
    prefix: string;
    scopes: ApiKeyScope[];
    rateLimitRpm?: number;
    lastUsedAt?: string;
    createdAt: string;
    type: "personal" | "service";
    ipAllowlist?: string[];
};

/** ===== Security & SSO ===== */
type SsoProvider = "saml" | "oidc";

/** ===== Database ===== */
type DbEngine = "postgresql" | "mysql" | "mssql" | "sqlite" | "mongodb";
type DbAuthMode = "url" | "fields";
type StorageDomain =
    | "users"
    | "roles"
    | "sessions"
    | "audit_logs"
    | "devices"
    | "policies"
    | "email_queue";

type DatabaseConfig = {
    enabled: boolean;
    engine: DbEngine;
    authMode: DbAuthMode;
    url: string;
    host: string;
    port: number | "";
    dbName: string;
    username: string;
    password: string;
    ssl: boolean;
    poolMin: number | "";
    poolMax: number | "";
    readReplicas: string;
    mappings: Record<StorageDomain, string>;
};

/** ===== S3 Storage ===== */
type S3Provider = "aws" | "minio" | "wasabi" | "other";
type StorageBackend = "local" | "s3";
type S3Config = {
    enabled: boolean;
    backend: StorageBackend;
    provider: S3Provider;
    accessKeyId: string;
    secretAccessKey: string;
    bucket: string;
    region: string;
    endpoint: string;
    prefix: string;
    pathStyle: boolean;
    sse: "none" | "AES256" | "aws:kms";
    kmsKeyId: string;
};

/** ===== Backups ===== */
type BackupTarget =
    | "users"
    | "roles"
    | "devices"
    | "policies"
    | "audit_logs"
    | "settings"
    | "templates";

type BackupDestination = { kind: "local" } | { kind: "s3"; bucket: string; prefix: string };

type BackupConfig = {
    enabled: boolean;
    targets: BackupTarget[];
    schedule: "hourly" | "daily" | "weekly" | "cron";
    cronExpr: string;
    retentionDays: number | "";
    encrypt: boolean;
    destination: BackupDestination;
};

type BackupHistoryRow = {
    id: string;
    at: string;
    status: "success" | "running" | "failed";
    note?: string;
};

/** ===== Email Templates ===== */
type TemplateKey = "invite" | "password_reset" | "alert";
type Template = { subject: string; body: string };

/** ===== Company ===== */
type CompanyInfo = {
    name: string;
    legalName: string;
    email: string;
    phone: string;
    fax: string;
    website: string;
    vatTin: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    postal: string;
    country: string;
};

/** ===== Billing (Gateways & Bank) ===== */
type Currency = "USD" | "EUR" | "GBP" | "CAD" | "AUD";
type TaxMode = "exclusive" | "inclusive" | "none";

type StripeCfg = { enabled: boolean; publishableKey: string; secretKey: string; webhookSecret: string };
type PaypalCfg = { enabled: boolean; clientId: string; clientSecret: string; mode: "live" | "sandbox" };
type SquareCfg = { enabled: boolean; accessToken: string; locationId: string };
type AuthorizeCfg = { enabled: boolean; apiLoginId: string; transactionKey: string };

type BankCfg = {
    enableACH: boolean;
    accountHolder: string;
    routingNumber: string;
    accountNumber: string;
    accountType: "checking" | "savings" | "";
    bankName: string;
};

type BillingConfig = {
    currency: Currency;
    taxMode: TaxMode;
    defaultTaxRate: number | "";
    statementDescriptor: string;
    stripe: StripeCfg;
    paypal: PaypalCfg;
    square: SquareCfg;
    authorize: AuthorizeCfg;
    bank: BankCfg;
};

/** ===== Invoices ===== */
type InvoiceConfig = {
    numberingPrefix: string;
    nextNumber: number | "";
    defaultNetTerms: 7 | 14 | 30 | 45 | 60;
    defaultDiscountPct: number | "";
    defaultLateFeePct: number | "";
    defaultNotes: string;
    footer: string;
    showCompanyAddress: boolean;
    attachPdfToEmail: boolean;
    emailFrom: string;
};

/** ===== Branding / Appearance ===== */
type BrandingSettings = {
    primaryColor: string;
    secondaryColor: string;
    emailHeader: string;
    emailFooter: string;
    customCss: string;
    allowClientThemeToggle: boolean;
};

/** ===== Localization ===== */
type LocalizationSettings = {
    language: "en-US" | "en-GB" | "es-ES" | "fr-FR";
    dateFormat: "MM/DD/YYYY" | "DD/MM/YYYY" | "YYYY-MM-DD";
    timeFormat: "12h" | "24h";
    numberFormat: "1,234.56" | "1.234,56";
    timeZone: string;
    firstDayOfWeek: "sunday" | "monday";
};

/** ===== Notifications ===== */
type NotificationChannel = "email" | "sms" | "slack" | "teams" | "push";
type NotificationRule = {
    id: string;
    event: string;
    severity: "info" | "warning" | "error" | "critical";
    channels: NotificationChannel[];
    recipients: string;
    enabled: boolean;
};

/** ===== Security Policies ===== */
type SecurityPolicySettings = {
    passwordMinLength: number | "";
    passwordRequireNumbers: boolean;
    passwordRequireSpecial: boolean;
    passwordRequireUppercase: boolean;
    passwordHistory: number | "";
    sessionTimeoutMins: number | "";
    idleLockMins: number | "";
    ipAllowlist: string;
    enableCaptcha: boolean;
};

/** ===== Integrations ===== */
type Integration = {
    id: "slack" | "teams" | "jira" | "servicenow" | "zendesk";
    name: string;
    connected: boolean;
};

/** ===== Subscription & Licensing ===== */
type SubscriptionInfo = {
    plan: string;
    seatsUsed: number;
    seatsTotal: number;
    renewalDate: string;
    licenseKey: string;
};

/** ===== Client Portal ===== */
type ClientPortalSettings = {
    enabledModules: ("dashboard" | "tickets" | "devices" | "invoices" | "reports")[];
    showSla: boolean;
    contactMethods: ("email" | "phone" | "portal")[];
};

export default function AdministrationPage() {
    const { toasts, push } = useToasts();

    /** ===== Users ===== */
    const [users, setUsers] = React.useState(
        [
            { id: "u1", name: "Alex Morgan", email: "alex@example.com", role: "Super Admin", status: "Active" },
            { id: "u2", name: "Jamie Lee", email: "jamie@example.com", role: "Admin", status: "Active" },
            { id: "u3", name: "Chris Kim", email: "chris@example.com", role: "Technician", status: "Suspended" },
        ] as { id: string; name: string; email: string; role: string; status: string }[]
    );
    const [query, setQuery] = React.useState("");
    const [removeUserId, setRemoveUserId] = React.useState<string | null>(null);
    const [inviteOpen, setInviteOpen] = React.useState(false);
    const [inviteEmails, setInviteEmails] = React.useState("");
    const [reset2FAUserId, setReset2FAUserId] = React.useState<string | null>(null);

    const filtered = users.filter(
        (u) => u.name.toLowerCase().includes(query.toLowerCase()) || u.email.toLowerCase().includes(query.toLowerCase())
    );

    function onConfirmRemoveUser() {
        if (!removeUserId) return;
        setUsers((prev) => prev.filter((p) => p.id !== removeUserId));
        setRemoveUserId(null);
        push({ title: "User removed", kind: "destructive" });
    }

    function onInviteUsers() {
        const emails = inviteEmails.split(",").map((e) => e.trim()).filter(Boolean);
        if (!emails.length) return push({ title: "No emails provided", kind: "warning" });
        emails.forEach((email) => {
            const id = Math.random().toString(36).slice(2, 8);
            setUsers((prev) => [{ id, name: "Invited User", email, role: "Technician", status: "Invited" }, ...prev]);
        });
        setInviteEmails("");
        setInviteOpen(false);
        push({ title: "Invitations sent", desc: `Sent to ${emails.length} recipient(s).`, kind: "success" });
    }

    /** ===== Roles ===== */
    const defaultPerms: Record<PermissionKey, boolean> = {
        view_devices: true,
        manage_devices: false,
        manage_users: false,
        billing_access: false,
        view_audit: true,
        manage_api: false,
        manage_flags: false,
    };
    const [roles, setRoles] = React.useState<Role[]>([
        { id: "r-tech", name: "Technician", permissions: { ...defaultPerms, view_devices: true, view_audit: true }, builtIn: true },
        { id: "r-admin", name: "Admin", permissions: { ...defaultPerms, manage_devices: true, manage_users: true, billing_access: true, manage_api: true }, builtIn: true },
        {
            id: "r-super",
            name: "Super Admin",
            permissions: { view_devices: true, manage_devices: true, manage_users: true, billing_access: true, view_audit: true, manage_api: true, manage_flags: true },
            builtIn: true,
        },
    ]);
    const [newRoleName, setNewRoleName] = React.useState("");
    const [deleteRoleId, setDeleteRoleId] = React.useState<string | null>(null);
    const [selectedRoleId, setSelectedRoleId] = React.useState<string | null>(roles[0]?.id ?? null);
    const selectedRole = React.useMemo(() => roles.find((r) => r.id === selectedRoleId) ?? null, [roles, selectedRoleId]);

    function createRole() {
        const name = newRoleName.trim();
        if (!name) return push({ title: "Role name required", kind: "warning" });
        if (roles.some((r) => r.name.toLowerCase() === name.toLowerCase())) return push({ title: "Role already exists", kind: "warning" });
        const role: Role = { id: Math.random().toString(36).slice(2), name, permissions: { ...defaultPerms } };
        setRoles((prev) => [role, ...prev]);
        setSelectedRoleId(role.id);
        setNewRoleName("");
        push({ title: "Role created", kind: "success", desc: name });
    }
    function togglePerm(roleId: string, key: PermissionKey) {
        setRoles((prev) => prev.map((r) => (r.id === roleId ? { ...r, permissions: { ...r.permissions, [key]: !r.permissions[key] } } : r)));
    }
    function confirmDeleteRole() {
        if (!deleteRoleId) return;
        setRoles((prev) => prev.filter((r) => r.id !== deleteRoleId));
        if (selectedRoleId === deleteRoleId) setSelectedRoleId(roles.find((r) => r.id !== deleteRoleId)?.id ?? null);
        setDeleteRoleId(null);
        push({ title: "Role deleted", kind: "destructive" });
    }

    /** ===== SMTP ===== */
    const [activePurpose, setActivePurpose] = React.useState<EmailPurpose>("alerts");
    const [emailProfiles, setEmailProfiles] = React.useState<Record<EmailPurpose, EmailProfile>>({
        alerts: {
            enabled: true,
            smtp: { host: "smtp.example.com", port: 587, username: "alerts@example.com", password: "", useTLS: true, useSSL: false, fromAddress: "alerts@your-msp.com" },
            imap: { host: "imap.example.com", port: 993, username: "alerts@example.com", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
        invites: {
            enabled: true,
            smtp: { host: "smtp.example.com", port: 587, username: "invites@example.com", password: "", useTLS: true, useSSL: false, fromAddress: "invites@your-msp.com" },
            imap: { host: "imap.example.com", port: 993, username: "invites@example.com", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
        password_resets: {
            enabled: true,
            smtp: { host: "smtp.example.com", port: 587, username: "passwords@example.com", password: "", useTLS: true, useSSL: false, fromAddress: "passwords@your-msp.com" },
            imap: { host: "imap.example.com", port: 993, username: "passwords@example.com", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
        reports: {
            enabled: false,
            smtp: { host: "", port: "", username: "", password: "", useTLS: true, useSSL: false, fromAddress: "reports@your-msp.com" },
            imap: { host: "", port: "", username: "", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
    });
    function updateProfile<K extends keyof EmailProfile>(purpose: EmailPurpose, key: K, value: EmailProfile[K]) {
        setEmailProfiles((prev) => ({ ...prev, [purpose]: { ...prev[purpose], [key]: value } }));
    }
    function updateSmtp(purpose: EmailPurpose, partial: Partial<SmtpSettings>) {
        const current = emailProfiles[purpose].smtp;
        updateProfile(purpose, "smtp", { ...current, ...partial });
    }
    function updateImap(purpose: EmailPurpose, partial: Partial<ImapSettings>) {
        const current = emailProfiles[purpose].imap;
        updateProfile(purpose, "imap", { ...current, ...partial });
    }
    function updatePop(purpose: EmailPurpose, partial: Partial<PopSettings>) {
        const current = emailProfiles[purpose].pop;
        updateProfile(purpose, "pop", { ...current, ...partial });
    }
    function saveEmailSettings() {
        push({ title: "SMTP settings saved", kind: "success", desc: `${activePurpose} profile` });
    }
    function testConnections() {
        push({ title: "Connection tests started", kind: "default", desc: `Testing ${activePurpose} (SMTP/IMAP/POP)` });
        setTimeout(() => push({ title: "SMTP OK • IMAP OK • POP OK", kind: "success", desc: `${activePurpose} profile` }), 900);
    }

    /** ===== Audit ===== */
    const [auditLogs] = React.useState<AuditLog[]>([
        { id: "a1", at: "2025-10-09 10:32", category: "user", severity: "warning", actor: "Admin", action: "User removed", details: "Removed chris@example.com" },
        { id: "a2", at: "2025-10-08 14:11", category: "role", severity: "info", actor: "System", action: "Role changed", details: "Jamie Lee → Admin" },
        { id: "a3", at: "2025-10-08 09:02", category: "auth", severity: "info", actor: "Alex Morgan", action: "Login", details: "IP 73.184.10.22" },
        { id: "a4", at: "2025-10-07 18:44", category: "email", severity: "error", actor: "Notifier", action: "Email send failed", details: "SMTP time-out for alerts@your-msp.com" },
        { id: "a5", at: "2025-10-07 12:05", category: "device", severity: "warning", actor: "PolicyEngine", action: "Patch policy skipped", details: "Outside maintenance window" },
        { id: "a6", at: "2025-10-06 21:10", category: "system", severity: "info", actor: "Admin", action: "Region changed", details: "Default region → US East" },
        { id: "a7", at: "2025-10-06 08:55", category: "security", severity: "error", actor: "AuthGuard", action: "Rate limited", details: "Excessive login attempts on jlee@example.com" },
    ]);

    const [auditQuery, setAuditQuery] = React.useState("");
    const [auditCategory, setAuditCategory] = React.useState<"all" | AuditCategory>("all");
    const [auditSeverity, setAuditSeverity] = React.useState<"all" | AuditSeverity>("all");
    const [auditFrom, setAuditFrom] = React.useState<string>("");
    const [auditTo, setAuditTo] = React.useState<string>("");

    const CATEGORY_LABELS: Record<AuditCategory, string> = {
        security: "Security",
        role: "Role Changes",
        user: "User Management",
        auth: "Authentication",
        email: "Email",
        device: "Devices",
        system: "System",
    };
    const SEVERITY_LABELS: Record<AuditSeverity, string> = { info: "Info", warning: "Warning", error: "Error" };

    const filteredAudit = React.useMemo(() => {
        const fromMs = auditFrom ? new Date(auditFrom).getTime() : null;
        const toMs = auditTo ? new Date(auditTo).getTime() + 24 * 60 * 60 * 1000 : null;
        const q = auditQuery.trim().toLowerCase();

        return auditLogs.filter((log) => {
            if (auditCategory !== "all" && log.category !== auditCategory) return false;
            if (auditSeverity !== "all" && log.severity !== auditSeverity) return false;

            const ts = Date.parse(log.at);
            if (!Number.isNaN(ts)) {
                if (fromMs && ts < fromMs) return false;
                if (toMs && ts >= toMs) return false;
            }

            if (!q) return true;
            const hay = `${log.action} ${log.details ?? ""} ${log.actor} ${log.category} ${log.severity}`.toLowerCase();
            return hay.includes(q);
        });
    }, [auditLogs, auditQuery, auditCategory, auditSeverity, auditFrom, auditTo]);

    const groupedAudit = React.useMemo(() => {
        return filteredAudit.reduce((acc, log) => {
            (acc[log.category] ||= []).push(log);
            return acc;
        }, {} as Record<AuditCategory, AuditLog[]>);
    }, [filteredAudit]);

    const orderedCategories: AuditCategory[] = ["security", "role", "user", "auth", "email", "device", "system"];

    function exportAuditCsv() {
        const headers = ["id", "at", "category", "severity", "actor", "action", "details"];
        const rows = [headers.join(",")].concat(
            filteredAudit.map((l) =>
                [
                    l.id,
                    `"${l.at}"`,
                    l.category,
                    l.severity,
                    `"${l.actor.replaceAll('"', '""')}"`,
                    `"${l.action.replaceAll('"', '""')}"`,
                    `"${(l.details ?? "").replaceAll('"', '""')}"`,
                ].join(",")
            )
        );
        const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `audit-logs.csv`;
        a.click();
        URL.revokeObjectURL(url);
    }

    /** ===== API ===== */
    const [apiKeys, setApiKeys] = React.useState<ApiKeyRow[]>([
        {
            id: "k1",
            label: "CI deploy bot",
            prefix: "rk_live_2fA7",
            scopes: ["read:devices", "write:devices", "read:audit"],
            rateLimitRpm: 600,
            createdAt: "2025-10-10 09:12",
            lastUsedAt: "2025-10-17 13:44",
            type: "service",
            ipAllowlist: ["0.0.0.0/0"],
        },
    ]);
    const [newKeyLabel, setNewKeyLabel] = React.useState("");
    const [newKeyType, setNewKeyType] = React.useState<"personal" | "service">("service");
    const [newKeyScopes, setNewKeyScopes] = React.useState<ApiKeyScope[]>(["read:devices"]);
    const [newKeyRate, setNewKeyRate] = React.useState<number | "">("");
    const [newKeyIps, setNewKeyIps] = React.useState("");
    const [revealKeyId, setRevealKeyId] = React.useState<string | null>(null);
    const [webhookSecret, setWebhookSecret] = React.useState("whsec_xxxxxxxx");
    const [webhookEvents, setWebhookEvents] = React.useState<string[]>(["device.created", "alert.fired"]);
    const [allowedOrigins, setAllowedOrigins] = React.useState("https://portal.example.com");

    function toggleScope(scope: ApiKeyScope) {
        setNewKeyScopes((prev) => (prev.includes(scope) ? prev.filter((s) => s !== scope) : [...prev, scope]));
    }
    function createApiKey() {
        if (!newKeyLabel.trim()) return push({ title: "Key label required", kind: "warning" });
        const id = Math.random().toString(36).slice(2);
        const prefix = "rk_live_" + Math.random().toString(36).slice(2, 6);
        setApiKeys((prev) => [
            {
                id,
                label: newKeyLabel.trim(),
                prefix,
                scopes: newKeyScopes,
                rateLimitRpm: newKeyRate === "" ? undefined : Number(newKeyRate),
                createdAt: new Date().toISOString().slice(0, 16).replace("T", " "),
                type: newKeyType,
                ipAllowlist: newKeyIps.split(",").map((s) => s.trim()).filter(Boolean),
            },
            ...prev,
        ]);
        setRevealKeyId(id);
        setNewKeyLabel("");
        setNewKeyType("service");
        setNewKeyScopes(["read:devices"]);
        setNewKeyRate("");
        setNewKeyIps("");
        push({ title: "API key created", kind: "success" });
    }
    function revokeKey(id: string) {
        setApiKeys((prev) => prev.filter((k) => k.id !== id));
        push({ title: "API key revoked", kind: "destructive" });
    }
    function rotateWebhookSecret() {
        const next = "whsec_" + Math.random().toString(36).slice(2, 10);
        setWebhookSecret(next);
        push({ title: "Webhook secret rotated", kind: "success" });
    }

    /** ===== 2FA + SSO ===== */
    const [require2FA, setRequire2FA] = React.useState<boolean>(false);
    const [twofaGraceDays, setTwofaGraceDays] = React.useState<number | "">("");
    const [ssoProvider, setSsoProvider] = React.useState<SsoProvider>("saml");

    const [saml, setSaml] = React.useState({
        metadataUrl: "",
        idpEntityId: "",
        idpSsoUrl: "",
        idpCertificate: "",
        nameIdFormat: "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress",
        attrEmail: "email",
        attrFirstName: "given_name",
        attrLastName: "family_name",
        attrGroups: "groups",
        jitProvisioning: true,
        groupRoleSync: true,
    });

    const [oidc, setOidc] = React.useState({
        issuer: "",
        clientId: "",
        clientSecret: "",
        scopes: "openid email profile",
        discoveryUrl: "",
    });

    function setNumOrEmpty(v: string, setter: (n: number | "") => void) {
        setter(v === "" ? "" : Number(v));
    }

    /** ===== Database ===== */
    const [db, setDb] = React.useState<DatabaseConfig>({
        enabled: false,
        engine: "postgresql",
        authMode: "fields",
        url: "",
        host: "localhost",
        port: 5432,
        dbName: "remoteiq",
        username: "remoteiq",
        password: "",
        ssl: true,
        poolMin: 1,
        poolMax: 10,
        readReplicas: "",
        mappings: {
            users: "users",
            roles: "roles",
            sessions: "sessions",
            audit_logs: "audit_logs",
            devices: "devices",
            policies: "policies",
            email_queue: "email_queue",
        },
    });

    /** ===== Storage (S3) ===== */
    const [s3, setS3] = React.useState<S3Config>({
        enabled: false,
        backend: "local",
        provider: "aws",
        accessKeyId: "",
        secretAccessKey: "",
        bucket: "",
        region: "us-east-1",
        endpoint: "",
        prefix: "",
        pathStyle: false,
        sse: "none",
        kmsKeyId: "",
    });

    /** ===== Backups ===== */
    const [backups, setBackups] = React.useState<BackupConfig>({
        enabled: false,
        targets: ["users", "roles", "devices", "settings"],
        schedule: "daily",
        cronExpr: "0 3 * * *",
        retentionDays: 30,
        encrypt: true,
        destination: { kind: "local" },
    });

    const [backupHistory, setBackupHistory] = React.useState<BackupHistoryRow[]>([
        { id: "b3", at: "2025-10-10 03:00", status: "success", note: "Daily backup" },
        { id: "b2", at: "2025-10-09 03:00", status: "success" },
        { id: "b1", at: "2025-10-08 03:00", status: "failed", note: "S3 permission denied" },
    ]);

    function toggleTarget(t: BackupTarget) {
        setBackups((prev) => ({
            ...prev,
            targets: prev.targets.includes(t) ? prev.targets.filter((x) => x !== t) : [...prev.targets, t],
        }));
    }

    /** ===== Email Templates ===== */
    const [templates, setTemplates] = React.useState<Record<TemplateKey, Template>>({
        invite: {
            subject: "You're invited to RemoteIQ",
            body:
                "Hi {{first_name}},\n\nYou've been invited to join RemoteIQ.\nClick here to accept: {{invite_link}}\n\nThanks,\n{{org_name}}",
        },
        password_reset: {
            subject: "Reset your RemoteIQ password",
            body:
                "Hi {{first_name}},\n\nWe received a request to reset your password.\nReset link: {{reset_link}}\n\nIf you didn't request this, ignore this email.",
        },
        alert: {
            subject: "[RemoteIQ] New alert: {{alert_name}}",
            body:
                "Alert: {{alert_name}}\nSeverity: {{severity}}\nDevice: {{device_name}}\nOccurred: {{timestamp}}\n\nView: {{alert_url}}",
        },
    });

    /** ===== Company ===== */
    const [company, setCompany] = React.useState<CompanyInfo>({
        name: "RemoteIQ",
        legalName: "RemoteIQ, Inc.",
        email: "info@remoteiq.local",
        phone: "+1 (555) 000-0000",
        fax: "",
        website: "https://remoteiq.local",
        vatTin: "",
        address1: "123 Example St",
        address2: "",
        city: "Anytown",
        state: "CA",
        postal: "90210",
        country: "US",
    });

    /** ===== Billing ===== */
    const [billing, setBilling] = React.useState<BillingConfig>({
        currency: "USD",
        taxMode: "exclusive",
        defaultTaxRate: 0,
        statementDescriptor: "REMOTEIQ",
        stripe: { enabled: false, publishableKey: "", secretKey: "", webhookSecret: "" },
        paypal: { enabled: false, clientId: "", clientSecret: "", mode: "sandbox" },
        square: { enabled: false, accessToken: "", locationId: "" },
        authorize: { enabled: false, apiLoginId: "", transactionKey: "" },
        bank: {
            enableACH: false,
            accountHolder: "",
            routingNumber: "",
            accountNumber: "",
            accountType: "",
            bankName: "",
        },
    });

    /** ===== Invoices ===== */
    const [invoices, setInvoices] = React.useState<InvoiceConfig>({
        numberingPrefix: "INV-",
        nextNumber: 1001,
        defaultNetTerms: 30,
        defaultDiscountPct: 0,
        defaultLateFeePct: 0,
        defaultNotes: "Thank you for your business!",
        footer: "RemoteIQ • 123 Example St • Anytown, CA 90210",
        showCompanyAddress: true,
        attachPdfToEmail: true,
        emailFrom: "billing@remoteiq.local",
    });


    /** ===== START: NEW SECTION STATE ===== */

    /** --- Branding --- */
    const [branding, setBranding] = React.useState<BrandingSettings>({
        primaryColor: "#09090b",
        secondaryColor: "#fafafa",
        emailHeader: "<h1>{{org_name}}</h1>",
        emailFooter: "<p>Copyright 2025. All rights reserved.</p>",
        customCss: "/* Your custom CSS here */",
        allowClientThemeToggle: true,
    });

    /** --- Localization --- */
    const [localization, setLocalization] = React.useState<LocalizationSettings>({
        language: "en-US",
        dateFormat: "MM/DD/YYYY",
        timeFormat: "12h",
        numberFormat: "1,234.56",
        timeZone: "America/New_York",
        firstDayOfWeek: "sunday",
    });

    /** --- Notifications --- */
    const [notifications, setNotifications] = React.useState<NotificationRule[]>([
        { id: 'nr1', event: 'New Critical Alert', severity: 'critical', channels: ['email', 'sms', 'push'], recipients: 'on-call@example.com', enabled: true },
        { id: 'nr2', event: 'Device Offline > 30m', severity: 'error', channels: ['slack'], recipients: '#ops-alerts', enabled: true },
        { id: 'nr3', event: 'User Login from New IP', severity: 'warning', channels: ['email'], recipients: 'security@example.com', enabled: false },
    ]);

    /** --- Security Policies --- */
    const [secPolicies, setSecPolicies] = React.useState<SecurityPolicySettings>({
        passwordMinLength: 12,
        passwordRequireNumbers: true,
        passwordRequireSpecial: true,
        passwordRequireUppercase: true,
        passwordHistory: 5,
        sessionTimeoutMins: 240,
        idleLockMins: 15,
        ipAllowlist: "0.0.0.0/0",
        enableCaptcha: true,
    });

    /** --- Integrations --- */
    const [integrations, setIntegrations] = React.useState<Integration[]>([
        { id: 'slack', name: 'Slack', connected: true },
        { id: 'teams', name: 'Microsoft Teams', connected: false },
        { id: 'jira', name: 'Jira', connected: false },
        { id: 'servicenow', name: 'ServiceNow', connected: true },
        { id: 'zendesk', name: 'Zendesk', connected: false },
    ]);

    /** --- Subscription & Licensing --- */
    const [subscription, setSubscription] = React.useState<SubscriptionInfo>({
        plan: "Enterprise",
        seatsUsed: 87,
        seatsTotal: 100,
        renewalDate: "2026-01-15",
        licenseKey: "RK-ENT-XXXX-XXXX-XXXX-XXXX"
    });

    /** --- Client Portal --- */
    const [clientPortal, setClientPortal] = React.useState<ClientPortalSettings>({
        enabledModules: ['dashboard', 'tickets', 'devices'],
        showSla: true,
        contactMethods: ['portal', 'email']
    });

    function toggleClientPortalModule(module: ClientPortalSettings['enabledModules'][0]) {
        setClientPortal(prev => {
            const modules = prev.enabledModules.includes(module)
                ? prev.enabledModules.filter(m => m !== module)
                : [...prev.enabledModules, module];
            return { ...prev, enabledModules: modules };
        });
    }

    function toggleClientPortalContact(method: ClientPortalSettings['contactMethods'][0]) {
        setClientPortal(prev => {
            const methods = prev.contactMethods.includes(method)
                ? prev.contactMethods.filter(m => m !== method)
                : [...prev.contactMethods, method];
            return { ...prev, contactMethods: methods };
        });
    }

    /** ===== END: NEW SECTION STATE ===== */


    /** ===== Render ===== */
    const [tab, setTab] = React.useState("users");

    return (
        <main className="p-4 sm:p-6">
            <div className="mx-auto max-w-7xl">
                <div className="mb-6">
                    <h1 className="text-xl font-semibold flex items-center gap-2">
                        <Shield className="h-5 w-5" /> Administration
                    </h1>
                    <p className="text-sm text-muted-foreground">
                        Organization-wide settings, users, roles, storage, billing and system controls.
                    </p>
                </div>

                <Tabs value={tab} onValueChange={setTab}>
                    <div className="grid grid-cols-[240px_1fr] items-start gap-6">
                        {/* LEFT: vertical admin nav */}
                        <aside className="w-[240px] shrink-0 self-start">
                            <div className="rounded-md border">
                                <TabsList className="flex h-auto w-full flex-col gap-1 bg-transparent p-2">
                                    {[
                                        // Existing
                                        { v: "users", label: "Users", Icon: Users },
                                        { v: "roles", label: "Roles", Icon: ShieldCheck },
                                        { v: "company", label: "Company", Icon: Building2 },
                                        { v: "billing", label: "Billing", Icon: CreditCard },
                                        { v: "invoices", label: "Invoices", Icon: ReceiptText },
                                        { v: "smtp", label: "SMTP", Icon: Mail },
                                        { v: "system", label: "System", Icon: ServerCog },
                                        { v: "sso", label: "SSO", Icon: Lock },
                                        { v: "database", label: "Database", Icon: DbIcon },
                                        { v: "storage", label: "Storage (S3)", Icon: Cloud },
                                        { v: "backups", label: "Backups", Icon: ArchiveRestore },
                                        { v: "templates", label: "Email Templates", Icon: FileSignature },
                                        { v: "audit", label: "Audit Logs", Icon: FileText },
                                        { v: "api", label: "API", Icon: KeyRound },
                                        { v: "flags", label: "Feature Flags", Icon: Rocket },

                                        // New
                                        { v: "branding", label: "Branding", Icon: Palette },
                                        { v: "localization", label: "Localization", Icon: Languages },
                                        { v: "notifications", label: "Notifications", Icon: BellRing },
                                        { v: "security_policies", label: "Security Policies", Icon: LockKeyhole },
                                        { v: "compliance", label: "Compliance", Icon: Gavel },
                                        { v: "integrations", label: "Integrations", Icon: Plug },
                                        { v: "agents", label: "Agents", Icon: Laptop2 },
                                        { v: "workflows", label: "Workflows", Icon: Workflow },
                                        { v: "import_export", label: "Import / Export", Icon: ArrowRightLeft },
                                        { v: "custom_fields", label: "Custom Fields", Icon: ListPlus },
                                        { v: "subscription", label: "Subscription", Icon: Gem },
                                        { v: "client_portal", label: "Client Portal", Icon: UserCog },
                                        { v: "sla", label: "SLA", Icon: CalendarClock },
                                        { v: "ticketing", label: "Ticketing", Icon: Ticket },
                                        { v: "secrets", label: "Secrets", Icon: Vault },
                                        { v: "sessions", label: "Session Mgmt", Icon: UserCheck },
                                        { v: "roles_matrix", label: "Roles Matrix", Icon: Table },
                                        { v: "migrations", label: "Data Migrations", Icon: DatabaseZap },
                                        { v: "reports", label: "Reports", Icon: BarChart3 },
                                        { v: "support", label: "Support & Legal", Icon: BookUser },

                                    ].map(({ v, label, Icon }) => (
                                        <TabsTrigger
                                            key={v}
                                            value={v}
                                            className={cn(
                                                "w-full justify-start rounded-md border px-3 py-2 text-sm",
                                                "bg-transparent hover:bg-transparent",
                                                "data-[state=active]:border-primary data-[state=active]:bg-primary/5 data-[state=active]:text-primary"
                                            )}
                                        >
                                            <Icon className="mr-2 h-4 w-4" />
                                            {label}
                                        </TabsTrigger>
                                    ))}
                                </TabsList>
                            </div>
                        </aside>

                        {/* RIGHT: tab content */}
                        <div className="min-w-0 flex-1 space-y-6 [&_[data-state=active]]:mt-0">
                            {/* Users */}
                            <TabsContent value="users" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>User Management</CardTitle>
                                        <CardDescription>Invite, suspend and manage members.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="flex flex-wrap items-center justify-between gap-2">
                                            <div className="relative w-full sm:w-72">
                                                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                                                <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search users…" className="pl-8" />
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Button variant="success" onClick={() => setInviteOpen(true)}>
                                                    <UserPlus className="mr-2 h-4 w-4" />
                                                    Invite user
                                                </Button>
                                            </div>
                                        </div>

                                        <div className="rounded-md border">
                                            <div className="grid grid-cols-12 border-b bg-muted/30 p-2 text-xs font-medium text-muted-foreground">
                                                <div className="col-span-3 px-2">Name</div>
                                                <div className="col-span-3 px-2">Email</div>
                                                <div className="col-span-2 px-2">Role</div>
                                                <div className="col-span-4 px-2 text-right">Actions</div>
                                            </div>
                                            {filtered.map((u) => (
                                                <div key={u.id} className="grid grid-cols-12 items-center border-b p-2 last:border-b-0">
                                                    <div className="col-span-3 px-2">{u.name}</div>
                                                    <div className="col-span-3 px-2 text-muted-foreground">{u.email}</div>
                                                    <div className="col-span-2 px-2 relative z-10">
                                                        <Select
                                                            value={u.role}
                                                            onValueChange={(v) => {
                                                                setUsers((prev) => prev.map((p) => (p.id === u.id ? { ...p, role: v } : p)));
                                                                push({ title: "Role updated", kind: "success" });
                                                            }}
                                                        >
                                                            <SelectTrigger className="h-8">
                                                                <SelectValue />
                                                            </SelectTrigger>
                                                            <SelectContent>
                                                                {roles.map((r) => (
                                                                    <SelectItem key={r.id} value={r.name}>
                                                                        {r.name}
                                                                    </SelectItem>
                                                                ))}
                                                            </SelectContent>
                                                        </Select>
                                                    </div>
                                                    <div className="col-span-4 px-2 flex items-center justify-end gap-2">
                                                        <Button
                                                            variant="outline"
                                                            size="sm"
                                                            onClick={() => push({ title: "Password reset sent", kind: "success", desc: u.email })}
                                                        >
                                                            <Lock className="mr-2 h-4 w-4" />
                                                            Reset
                                                        </Button>
                                                        <Button
                                                            variant="outline"
                                                            size="sm"
                                                            onClick={() => setReset2FAUserId(u.id)}
                                                            title="Invalidate current 2FA device and require re-enrollment"
                                                        >
                                                            <Shield className="mr-2 h-4 w-4" />
                                                            Reset 2FA
                                                        </Button>
                                                        <Button variant="destructive" size="sm" onClick={() => setRemoveUserId(u.id)}>
                                                            <Trash2 className="mr-2 h-4 w-4" />
                                                            Remove
                                                        </Button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Roles */}
                            <TabsContent value="roles" className="mt-0">
                                <Card>
                                    <CardHeader className="space-y-1">
                                        <CardTitle>Roles & Permissions</CardTitle>
                                        <CardDescription>Define access levels across the app.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-4">
                                        <div className="flex items-end gap-2">
                                            <div className="grid gap-1">
                                                <Label htmlFor="new-role">Create a new role</Label>
                                                <div className="flex items-center gap-2">
                                                    <Input id="new-role" value={newRoleName} onChange={(e) => setNewRoleName(e.target.value)} placeholder="e.g., Helpdesk" className="w-64" />
                                                    <Button variant="success" onClick={createRole}>
                                                        <Plus className="mr-2 h-4 w-4" />
                                                        Add role
                                                    </Button>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="flex items-end gap-2">
                                            <div className="grid gap-1">
                                                <Label>Choose a role to edit</Label>
                                                <Select value={selectedRoleId ?? undefined} onValueChange={(v) => setSelectedRoleId(v)}>
                                                    <SelectTrigger className="w-64">
                                                        <SelectValue placeholder="Select a role" />
                                                    </SelectTrigger>
                                                    <SelectContent>
                                                        {roles.map((r) => (
                                                            <SelectItem key={r.id} value={r.id}>
                                                                {r.name}
                                                            </SelectItem>
                                                        ))}
                                                    </SelectContent>
                                                </Select>
                                            </div>

                                            {selectedRole && (
                                                <div className="ml-auto flex items-center gap-2">
                                                    <Button variant="outline" size="sm" onClick={() => push({ title: "Role saved", kind: "success", desc: selectedRole.name })}>
                                                        <Settings className="mr-2 h-4 w-4" />
                                                        Save
                                                    </Button>
                                                    <Button
                                                        variant="destructive"
                                                        size="sm"
                                                        disabled={selectedRole.builtIn}
                                                        onClick={() => setDeleteRoleId(selectedRole.id)}
                                                        title={selectedRole.builtIn ? "Built-in role cannot be deleted" : "Delete role"}
                                                    >
                                                        <Trash className="mr-2 h-4 w-4" />
                                                        Delete
                                                    </Button>
                                                </div>
                                            )}
                                        </div>

                                        {selectedRole ? (
                                            <div className="rounded-md border p-3 space-y-2">
                                                <div className="text-sm text-muted-foreground">
                                                    Editing: <span className="font-medium">{selectedRole.name}</span>
                                                </div>

                                                <PermRow label="View devices" checked={selectedRole.permissions.view_devices} onChecked={() => togglePerm(selectedRole.id, "view_devices")} />
                                                <PermRow label="Manage devices" checked={selectedRole.permissions.manage_devices} onChecked={() => togglePerm(selectedRole.id, "manage_devices")} />
                                                <PermRow label="Manage users" checked={selectedRole.permissions.manage_users} onChecked={() => togglePerm(selectedRole.id, "manage_users")} />
                                                <PermRow label="Billing access" checked={selectedRole.permissions.billing_access} onChecked={() => togglePerm(selectedRole.id, "billing_access")} />
                                                <PermRow label="View audit logs" checked={selectedRole.permissions.view_audit} onChecked={() => togglePerm(selectedRole.id, "view_audit")} />
                                                <PermRow label="Manage API" checked={selectedRole.permissions.manage_api} onChecked={() => togglePerm(selectedRole.id, "manage_api")} />
                                                <PermRow label="Manage feature flags" checked={selectedRole.permissions.manage_flags} onChecked={() => togglePerm(selectedRole.id, "manage_flags")} />
                                            </div>
                                        ) : (
                                            <div className="text-sm text-muted-foreground">Select a role to edit its permissions.</div>
                                        )}
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Company */}
                            <TabsContent value="company" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Company Profile</CardTitle>
                                        <CardDescription>Set your company details used across invoices, emails, and the client billing page.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid gap-3 md:grid-cols-3">
                                            <LabeledInput label="Company name" value={company.name} onChange={(v) => setCompany({ ...company, name: v })} />
                                            <LabeledInput label="Legal name" value={company.legalName} onChange={(v) => setCompany({ ...company, legalName: v })} />
                                            <LabeledInput label="Website" value={company.website} onChange={(v) => setCompany({ ...company, website: v })} />
                                            <LabeledInput label="Email" value={company.email} onChange={(v) => setCompany({ ...company, email: v })} />
                                            <LabeledInput label="Phone" value={company.phone} onChange={(v) => setCompany({ ...company, phone: v })} />
                                            <LabeledInput label="Fax" value={company.fax} onChange={(v) => setCompany({ ...company, fax: v })} />
                                            <LabeledInput label="VAT / TIN" value={company.vatTin} onChange={(v) => setCompany({ ...company, vatTin: v })} />
                                        </div>

                                        <Separator />

                                        <div className="grid gap-3 md:grid-cols-3">
                                            <LabeledInput label="Address line 1" value={company.address1} onChange={(v) => setCompany({ ...company, address1: v })} />
                                            <LabeledInput label="Address line 2" value={company.address2} onChange={(v) => setCompany({ ...company, address2: v })} />
                                            <LabeledInput label="City" value={company.city} onChange={(v) => setCompany({ ...company, city: v })} />
                                            <LabeledInput label="State / Region" value={company.state} onChange={(v) => setCompany({ ...company, state: v })} />
                                            <LabeledInput label="Postal code" value={company.postal} onChange={(v) => setCompany({ ...company, postal: v })} />
                                            <LabeledInput label="Country" value={company.country} onChange={(v) => setCompany({ ...company, country: v })} />
                                        </div>

                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Company profile saved", kind: "success" })}>
                                                Save company
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Billing */}
                            <TabsContent value="billing" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Billing Settings</CardTitle>
                                        <CardDescription>Configure currency, taxes, payment gateways, and bank/ACH for client billing.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid gap-3 md:grid-cols-3">
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Currency</Label>
                                                <Select value={billing.currency} onValueChange={(v: Currency) => setBilling({ ...billing, currency: v })}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="USD">USD</SelectItem>
                                                        <SelectItem value="EUR">EUR</SelectItem>
                                                        <SelectItem value="GBP">GBP</SelectItem>
                                                        <SelectItem value="CAD">CAD</SelectItem>
                                                        <SelectItem value="AUD">AUD</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Tax mode</Label>
                                                <Select value={billing.taxMode} onValueChange={(v: TaxMode) => setBilling({ ...billing, taxMode: v })}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="exclusive">Tax exclusive</SelectItem>
                                                        <SelectItem value="inclusive">Tax inclusive</SelectItem>
                                                        <SelectItem value="none">No tax</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <LabeledNumber label="Default tax rate (%)" value={billing.defaultTaxRate} onChange={(v) => setBilling({ ...billing, defaultTaxRate: v })} />
                                            <LabeledInput label="Statement descriptor" value={billing.statementDescriptor} onChange={(v) => setBilling({ ...billing, statementDescriptor: v })} />
                                        </div>

                                        <Separator />

                                        {/* Stripe */}
                                        <section className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <CreditCard className="h-4 w-4" />
                                                    <div className="font-medium">Stripe</div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Switch
                                                        checked={billing.stripe.enabled}
                                                        onCheckedChange={(v) => setBilling({ ...billing, stripe: { ...billing.stripe, enabled: v } })}
                                                    />
                                                    <span className="text-sm">{billing.stripe.enabled ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>
                                            {billing.stripe.enabled && (
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Publishable key" value={billing.stripe.publishableKey} onChange={(v) => setBilling({ ...billing, stripe: { ...billing.stripe, publishableKey: v } })} />
                                                    <LabeledInput label="Secret key" type="password" value={billing.stripe.secretKey} onChange={(v) => setBilling({ ...billing, stripe: { ...billing.stripe, secretKey: v } })} />
                                                    <LabeledInput label="Webhook secret" value={billing.stripe.webhookSecret} onChange={(v) => setBilling({ ...billing, stripe: { ...billing.stripe, webhookSecret: v } })} />
                                                    <LabeledInput label="Webhook endpoint (read-only)" value="https://portal.remoteiq.local/api/billing/stripe/webhook" onChange={() => { }} />
                                                </div>
                                            )}
                                        </section>

                                        {/* PayPal */}
                                        <section className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="font-medium">PayPal</div>
                                                <div className="flex items-center gap-2">
                                                    <Switch
                                                        checked={billing.paypal.enabled}
                                                        onCheckedChange={(v) => setBilling({ ...billing, paypal: { ...billing.paypal, enabled: v } })}
                                                    />
                                                    <span className="text-sm">{billing.paypal.enabled ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>
                                            {billing.paypal.enabled && (
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Client ID" value={billing.paypal.clientId} onChange={(v) => setBilling({ ...billing, paypal: { ...billing.paypal, clientId: v } })} />
                                                    <LabeledInput label="Client Secret" type="password" value={billing.paypal.clientSecret} onChange={(v) => setBilling({ ...billing, paypal: { ...billing.paypal, clientSecret: v } })} />
                                                    <div className="grid gap-1">
                                                        <Label className="text-sm">Mode</Label>
                                                        <Select value={billing.paypal.mode} onValueChange={(v: "live" | "sandbox") => setBilling({ ...billing, paypal: { ...billing.paypal, mode: v } })}>
                                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="sandbox">Sandbox</SelectItem>
                                                                <SelectItem value="live">Live</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    </div>
                                                </div>
                                            )}
                                        </section>

                                        {/* Square */}
                                        <section className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="font-medium">Square</div>
                                                <div className="flex items-center gap-2">
                                                    <Switch
                                                        checked={billing.square.enabled}
                                                        onCheckedChange={(v) => setBilling({ ...billing, square: { ...billing.square, enabled: v } })}
                                                    />
                                                    <span className="text-sm">{billing.square.enabled ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>
                                            {billing.square.enabled && (
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Access token" type="password" value={billing.square.accessToken} onChange={(v) => setBilling({ ...billing, square: { ...billing.square, accessToken: v } })} />
                                                    <LabeledInput label="Location ID" value={billing.square.locationId} onChange={(v) => setBilling({ ...billing, square: { ...billing.square, locationId: v } })} />
                                                </div>
                                            )}
                                        </section>

                                        {/* Authorize.Net */}
                                        <section className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="font-medium">Authorize.Net</div>
                                                <div className="flex items-center gap-2">
                                                    <Switch
                                                        checked={billing.authorize.enabled}
                                                        onCheckedChange={(v) => setBilling({ ...billing, authorize: { ...billing.authorize, enabled: v } })}
                                                    />
                                                    <span className="text-sm">{billing.authorize.enabled ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>
                                            {billing.authorize.enabled && (
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="API Login ID" value={billing.authorize.apiLoginId} onChange={(v) => setBilling({ ...billing, authorize: { ...billing.authorize, apiLoginId: v } })} />
                                                    <LabeledInput label="Transaction Key" type="password" value={billing.authorize.transactionKey} onChange={(v) => setBilling({ ...billing, authorize: { ...billing.authorize, transactionKey: v } })} />
                                                </div>
                                            )}
                                        </section>

                                        <Separator />

                                        {/* Bank / ACH */}
                                        <section className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <Landmark className="h-4 w-4" />
                                                    <div className="font-medium">Bank / ACH</div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Switch
                                                        checked={billing.bank.enableACH}
                                                        onCheckedChange={(v) => setBilling({ ...billing, bank: { ...billing.bank, enableACH: v } })}
                                                    />
                                                    <span className="text-sm">{billing.bank.enableACH ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>
                                            {billing.bank.enableACH && (
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Account holder" value={billing.bank.accountHolder} onChange={(v) => setBilling({ ...billing, bank: { ...billing.bank, accountHolder: v } })} />
                                                    <LabeledInput label="Bank name" value={billing.bank.bankName} onChange={(v) => setBilling({ ...billing, bank: { ...billing.bank, bankName: v } })} />
                                                    <LabeledInput label="Routing number" value={billing.bank.routingNumber} onChange={(v) => setBilling({ ...billing, bank: { ...billing.bank, routingNumber: v } })} />
                                                    <LabeledInput label="Account number" type="password" value={billing.bank.accountNumber} onChange={(v) => setBilling({ ...billing, bank: { ...billing.bank, accountNumber: v } })} />
                                                    <div className="grid gap-1">
                                                        <Label className="text-sm">Account type</Label>
                                                        <Select
                                                            value={billing.bank.accountType}
                                                            onValueChange={(v: "checking" | "savings") => setBilling({ ...billing, bank: { ...billing.bank, accountType: v } })}
                                                        >
                                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="checking">Checking</SelectItem>
                                                                <SelectItem value="savings">Savings</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    </div>
                                                </div>
                                            )}
                                        </section>

                                        <div className="flex items-center justify-end gap-2">
                                            <Button variant="outline" onClick={() => push({ title: "Testing gateways…", kind: "default" })}>
                                                Test gateways
                                            </Button>
                                            <Button variant="success" onClick={() => push({ title: "Billing settings saved", kind: "success" })}>
                                                Save billing
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Invoices */}
                            <TabsContent value="invoices" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Invoice Settings</CardTitle>
                                        <CardDescription>Configure invoice numbering, defaults, branding and email delivery.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid gap-3 md:grid-cols-3">
                                            <LabeledInput label="Numbering prefix" value={invoices.numberingPrefix} onChange={(v) => setInvoices({ ...invoices, numberingPrefix: v })} />
                                            <LabeledNumber label="Next number" value={invoices.nextNumber} onChange={(v) => setInvoices({ ...invoices, nextNumber: v })} />
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Default net terms</Label>
                                                <Select
                                                    value={String(invoices.defaultNetTerms)}
                                                    onValueChange={(v) => setInvoices({ ...invoices, defaultNetTerms: Number(v) as InvoiceConfig["defaultNetTerms"] })}
                                                >
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="7">Net 7</SelectItem>
                                                        <SelectItem value="14">Net 14</SelectItem>
                                                        <SelectItem value="30">Net 30</SelectItem>
                                                        <SelectItem value="45">Net 45</SelectItem>
                                                        <SelectItem value="60">Net 60</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <LabeledNumber label="Default discount (%)" value={invoices.defaultDiscountPct} onChange={(v) => setInvoices({ ...invoices, defaultDiscountPct: v })} />
                                            <LabeledNumber label="Late fee (% per period)" value={invoices.defaultLateFeePct} onChange={(v) => setInvoices({ ...invoices, defaultLateFeePct: v })} />
                                            <LabeledInput label="Email from" value={invoices.emailFrom} onChange={(v) => setInvoices({ ...invoices, emailFrom: v })} />
                                        </div>

                                        <div className="grid gap-3">
                                            <LabeledTextarea label="Default notes" value={invoices.defaultNotes} onChange={(v) => setInvoices({ ...invoices, defaultNotes: v })} rows={5} />
                                            <LabeledTextarea label="Footer / Legal text" value={invoices.footer} onChange={(v) => setInvoices({ ...invoices, footer: v })} rows={4} />
                                        </div>

                                        <div className="flex flex-wrap items-center gap-6">
                                            <CheckToggle
                                                label="Show company address on invoices"
                                                checked={invoices.showCompanyAddress}
                                                onChange={(v) => setInvoices({ ...invoices, showCompanyAddress: v })}
                                            />
                                            <CheckToggle
                                                label="Attach PDF when emailing"
                                                checked={invoices.attachPdfToEmail}
                                                onChange={(v) => setInvoices({ ...invoices, attachPdfToEmail: v })}
                                            />
                                        </div>

                                        <div className="flex items-center justify-end gap-2">
                                            <Button variant="outline" onClick={() => push({ title: "Sample invoice generated", kind: "success" })}>
                                                Generate sample
                                            </Button>
                                            <Button variant="success" onClick={() => push({ title: "Invoice settings saved", kind: "success" })}>
                                                Save invoices
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* SMTP (unchanged) */}
                            <TabsContent value="smtp" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>SMTP Settings</CardTitle>
                                        <CardDescription>Configure SMTP/IMAP/POP per purpose (Alerts, Invites, Password Resets, Reports).</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="flex flex-wrap items-center gap-2">
                                            <Label className="text-sm">Purpose</Label>
                                            <Select value={activePurpose} onValueChange={(v: EmailPurpose) => setActivePurpose(v)}>
                                                <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="alerts">Alerts</SelectItem>
                                                    <SelectItem value="invites">Invites</SelectItem>
                                                    <SelectItem value="password_resets">Password Resets</SelectItem>
                                                    <SelectItem value="reports">Reports</SelectItem>
                                                </SelectContent>
                                            </Select>
                                            <div className="flex items-center gap-2 ml-auto">
                                                <Switch checked={emailProfiles[activePurpose].enabled} onCheckedChange={(v) => updateProfile(activePurpose, "enabled", v)} />
                                                <span className="text-sm">{emailProfiles[activePurpose].enabled ? "Enabled" : "Disabled"}</span>
                                            </div>
                                        </div>

                                        <Separator />

                                        {/* SMTP */}
                                        <section className="space-y-3">
                                            <div className="flex items-center gap-2">
                                                <Mail className="h-4 w-4" />
                                                <h3 className="font-medium">SMTP</h3>
                                            </div>
                                            <div className="grid gap-3 md:grid-cols-3">
                                                <LabeledInput label="Host" value={emailProfiles[activePurpose].smtp.host} onChange={(v) => updateSmtp(activePurpose, { host: v })} />
                                                <LabeledNumber label="Port" value={emailProfiles[activePurpose].smtp.port} onChange={(v) => updateSmtp(activePurpose, { port: v })} />
                                                <LabeledInput label="From Address" value={emailProfiles[activePurpose].smtp.fromAddress} onChange={(v) => updateSmtp(activePurpose, { fromAddress: v })} />
                                                <LabeledInput label="Username" value={emailProfiles[activePurpose].smtp.username} onChange={(v) => updateSmtp(activePurpose, { username: v })} />
                                                <LabeledInput label="Password" type="password" value={emailProfiles[activePurpose].smtp.password} onChange={(v) => updateSmtp(activePurpose, { password: v })} />
                                                <div className="flex items-center gap-6 mt-6">
                                                    <CheckToggle label="Use TLS (STARTTLS)" checked={emailProfiles[activePurpose].smtp.useTLS} onChange={(v) => updateSmtp(activePurpose, { useTLS: v })} />
                                                    <CheckToggle label="Use SSL" checked={emailProfiles[activePurpose].smtp.useSSL} onChange={(v) => updateSmtp(activePurpose, { useSSL: v })} />
                                                </div>
                                            </div>
                                        </section>

                                        <Separator />

                                        {/* IMAP */}
                                        <section className="space-y-3">
                                            <div className="flex items-center gap-2">
                                                <Globe className="h-4 w-4" />
                                                <h3 className="font-medium">IMAP</h3>
                                            </div>
                                            <div className="grid gap-3 md:grid-cols-3">
                                                <LabeledInput label="Host" value={emailProfiles[activePurpose].imap.host} onChange={(v) => updateImap(activePurpose, { host: v })} />
                                                <LabeledNumber label="Port" value={emailProfiles[activePurpose].imap.port} onChange={(v) => updateImap(activePurpose, { port: v })} />
                                                <div className="flex items-center gap-6 mt-6">
                                                    <CheckToggle label="Use SSL" checked={emailProfiles[activePurpose].imap.useSSL} onChange={(v) => updateImap(activePurpose, { useSSL: v })} />
                                                </div>
                                                <LabeledInput label="Username" value={emailProfiles[activePurpose].imap.username} onChange={(v) => updateImap(activePurpose, { username: v })} />
                                                <LabeledInput label="Password" type="password" value={emailProfiles[activePurpose].imap.password} onChange={(v) => updateImap(activePurpose, { password: v })} />
                                            </div>
                                        </section>

                                        <Separator />

                                        {/* POP */}
                                        <section className="space-y-3">
                                            <div className="flex items-center gap-2">
                                                <Bell className="h-4 w-4" />
                                                <h3 className="font-medium">POP</h3>
                                            </div>
                                            <div className="grid gap-3 md:grid-cols-3">
                                                <LabeledInput label="Host" value={emailProfiles[activePurpose].pop.host} onChange={(v) => updatePop(activePurpose, { host: v })} />
                                                <LabeledNumber label="Port" value={emailProfiles[activePurpose].pop.port} onChange={(v) => updatePop(activePurpose, { port: v })} />
                                                <div className="flex items-center gap-6 mt-6">
                                                    <CheckToggle label="Use SSL" checked={emailProfiles[activePurpose].pop.useSSL} onChange={(v) => updatePop(activePurpose, { useSSL: v })} />
                                                </div>
                                                <LabeledInput label="Username" value={emailProfiles[activePurpose].pop.username} onChange={(v) => updatePop(activePurpose, { username: v })} />
                                                <LabeledInput label="Password" type="password" value={emailProfiles[activePurpose].pop.password} onChange={(v) => updatePop(activePurpose, { password: v })} />
                                            </div>
                                        </section>

                                        <div className="flex items-center justify-end gap-2">
                                            <Button variant="outline" onClick={testConnections}>
                                                <TestTube2 className="mr-2 h-4 w-4" />
                                                Test connections
                                            </Button>
                                            <Button variant="success" onClick={saveEmailSettings}>
                                                Save SMTP settings
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* System */}
                            <TabsContent value="system" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>System Settings</CardTitle>
                                        <CardDescription>Organization-wide defaults and infrastructure.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid gap-4 md:grid-cols-2">
                                            <SettingCard icon={<Globe className="h-4 w-4" />} title="Default region" desc="Choose the default backend region for agents.">
                                                <Select defaultValue="us-east-1">
                                                    <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="us-east-1">US East</SelectItem>
                                                        <SelectItem value="us-west-2">US West</SelectItem>
                                                        <SelectItem value="eu-central-1">EU Central</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </SettingCard>

                                            <SettingCard icon={<Wrench className="h-4 w-4" />} title="Maintenance window" desc="Weekly patching window for default policies.">
                                                <Select defaultValue="sun-2am">
                                                    <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="sun-2am">Sunday 2:00 AM</SelectItem>
                                                        <SelectItem value="wed-1am">Wednesday 1:00 AM</SelectItem>
                                                        <SelectItem value="fri-11pm">Friday 11:00 PM</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </SettingCard>

                                            <SettingCard icon={<ActivitySquare className="h-4 w-4" />} title="Telemetry" desc="Anonymous usage metrics to improve RemoteIQ.">
                                                <div className="flex items-center gap-3">
                                                    <Switch defaultChecked />
                                                    <span className="text-sm">Enabled</span>
                                                </div>
                                            </SettingCard>

                                            <SettingCard icon={<Shield className="h-4 w-4" />} title="Two-Factor Authentication" desc="Require 2FA for all users and set an optional grace period.">
                                                <div className="flex flex-wrap items-center gap-4">
                                                    <div className="flex items-center gap-3">
                                                        <Switch checked={require2FA} onCheckedChange={setRequire2FA} />
                                                        <span className="text-sm">{require2FA ? "Required for all users" : "Optional"}</span>
                                                    </div>
                                                    <div className="grid gap-1">
                                                        <Label className="text-sm">Grace period (days)</Label>
                                                        <Input className="w-28" inputMode="numeric" value={twofaGraceDays} onChange={(e) => setNumOrEmpty(e.target.value, setTwofaGraceDays)} placeholder="0" disabled={!require2FA} />
                                                    </div>
                                                </div>
                                            </SettingCard>
                                        </div>

                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "System settings saved", kind: "success" })}>
                                                Save system settings
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* SSO */}
                            <TabsContent value="sso" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Single Sign-On (SSO)</CardTitle>
                                        <CardDescription>Configure SAML 2.0 or OIDC for centralized authentication.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="flex items-center gap-2">
                                            <Label className="text-sm">Provider</Label>
                                            <Select value={ssoProvider} onValueChange={(v: SsoProvider) => setSsoProvider(v)}>
                                                <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                                                <SelectContent>
                                                    <SelectItem value="saml">SAML 2.0</SelectItem>
                                                    <SelectItem value="oidc">OIDC (Okta/Azure AD)</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </div>

                                        {ssoProvider === "saml" ? (
                                            <div className="space-y-4">
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Metadata URL (IdP)" value={saml.metadataUrl} onChange={(v) => setSaml({ ...saml, metadataUrl: v })} placeholder="https://idp.example.com/metadata" />
                                                    <LabeledInput label="IdP Entity ID" value={saml.idpEntityId} onChange={(v) => setSaml({ ...saml, idpEntityId: v })} placeholder="urn:example:idp" />
                                                    <LabeledInput label="IdP SSO URL" value={saml.idpSsoUrl} onChange={(v) => setSaml({ ...saml, idpSsoUrl: v })} placeholder="https://idp.example.com/sso" />
                                                </div>

                                                <div className="grid gap-1">
                                                    <Label className="text-sm">IdP Signing Certificate (PEM)</Label>
                                                    <Textarea value={saml.idpCertificate} onChange={(e) => setSaml({ ...saml, idpCertificate: e.target.value })} rows={6} placeholder="-----BEGIN CERTIFICATE----- … -----END CERTIFICATE-----" />
                                                </div>

                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <div className="grid gap-1">
                                                        <Label className="text-sm">NameID Format</Label>
                                                        <Select value={saml.nameIdFormat} onValueChange={(v) => setSaml({ ...saml, nameIdFormat: v })}>
                                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress">Email</SelectItem>
                                                                <SelectItem value="urn:oasis:names:tc:SAML:2.0:nameid-format:persistent">Persistent</SelectItem>
                                                                <SelectItem value="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified">Unspecified</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    </div>
                                                    <LabeledInput label="SP Entity ID" value="urn:remoteiq:sp" onChange={() => { }} />
                                                    <LabeledInput label="ACS URL" value="https://portal.remoteiq.local/sso/saml/acs" onChange={() => { }} />
                                                </div>

                                                <Separator />

                                                <div className="grid gap-3 md:grid-cols-4">
                                                    <LabeledInput label="Attribute: Email" value={saml.attrEmail} onChange={(v) => setSaml({ ...saml, attrEmail: v })} />
                                                    <LabeledInput label="Attribute: First name" value={saml.attrFirstName} onChange={(v) => setSaml({ ...saml, attrFirstName: v })} />
                                                    <LabeledInput label="Attribute: Last name" value={saml.attrLastName} onChange={(v) => setSaml({ ...saml, attrLastName: v })} />
                                                    <LabeledInput label="Attribute: Groups" value={saml.attrGroups} onChange={(v) => setSaml({ ...saml, attrGroups: v })} />
                                                </div>

                                                <div className="flex flex-wrap items-center gap-6">
                                                    <CheckToggle label="Just-in-time user provisioning" checked={saml.jitProvisioning} onChange={(v) => setSaml({ ...saml, jitProvisioning: v })} />
                                                    <CheckToggle label="Map IdP groups to roles" checked={saml.groupRoleSync} onChange={(v) => setSaml({ ...saml, groupRoleSync: v })} />
                                                </div>

                                                <div className="text-right">
                                                    <Button variant="success" onClick={() => push({ title: "SAML settings saved", kind: "success" })}>
                                                        Save SAML
                                                    </Button>
                                                </div>
                                            </div>
                                        ) : (
                                            <div className="space-y-4">
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Issuer" value={oidc.issuer} onChange={(v) => setOidc({ ...oidc, issuer: v })} placeholder="https://login.microsoftonline.com/{tenant}/v2.0" />
                                                    <LabeledInput label="Client ID" value={oidc.clientId} onChange={(v) => setOidc({ ...oidc, clientId: v })} />
                                                    <LabeledInput label="Client Secret" type="password" value={oidc.clientSecret} onChange={(v) => setOidc({ ...oidc, clientSecret: v })} />
                                                </div>

                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Scopes" value={oidc.scopes} onChange={(v) => setOidc({ ...oidc, scopes: v })} placeholder="openid email profile" />
                                                    <LabeledInput label="Discovery URL (optional)" value={oidc.discoveryUrl} onChange={(v) => setOidc({ ...oidc, discoveryUrl: v })} placeholder="https://…/.well-known/openid-configuration" />
                                                    <LabeledInput label="Redirect URI" value="https://portal.remoteiq.local/sso/oidc/callback" onChange={() => { }} />
                                                </div>

                                                <div className="text-right">
                                                    <Button variant="success" onClick={() => push({ title: "OIDC settings saved", kind: "success" })}>
                                                        Save OIDC
                                                    </Button>
                                                </div>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Database */}
                            <TabsContent value="database" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Database</CardTitle>
                                        <CardDescription>Use an external database for organization storage (users, roles, audit, devices, etc.).</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3">
                                                    <DbIcon className="h-4 w-4" />
                                                    <div className="font-medium">External Database</div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Switch checked={db.enabled} onCheckedChange={(v) => setDb({ ...db, enabled: v })} />
                                                    <span className="text-sm">{db.enabled ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>

                                            <div className="grid gap-3 md:grid-cols-3">
                                                <div className="grid gap-1">
                                                    <Label className="text-sm">Engine</Label>
                                                    <Select value={db.engine} onValueChange={(v: DbEngine) => setDb({ ...db, engine: v })}>
                                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="postgresql">PostgreSQL</SelectItem>
                                                            <SelectItem value="mysql">MySQL / MariaDB</SelectItem>
                                                            <SelectItem value="mssql">SQL Server</SelectItem>
                                                            <SelectItem value="sqlite">SQLite</SelectItem>
                                                            <SelectItem value="mongodb">MongoDB</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>

                                                <div className="grid gap-1">
                                                    <Label className="text-sm">Auth mode</Label>
                                                    <Select value={db.authMode} onValueChange={(v: DbAuthMode) => setDb({ ...db, authMode: v })}>
                                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="fields">Fields</SelectItem>
                                                            <SelectItem value="url">Connection URL</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>

                                                <div className="grid gap-1">
                                                    <Label className="text-sm">SSL</Label>
                                                    <div className="flex items-center gap-3 h-10">
                                                        <Switch checked={db.ssl} onCheckedChange={(v) => setDb({ ...db, ssl: v })} />
                                                        <span className="text-sm">{db.ssl ? "On" : "Off"}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        {db.authMode === "url" ? (
                                            <div className="rounded-md border p-3 space-y-2">
                                                <Label className="text-sm">Connection URL</Label>
                                                <Input placeholder="postgres://user:pass@host:5432/dbname?sslmode=require" value={db.url} onChange={(e) => setDb({ ...db, url: e.target.value })} />
                                            </div>
                                        ) : (
                                            <div className="rounded-md border p-3">
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <LabeledInput label="Host" value={db.host} onChange={(v) => setDb({ ...db, host: v })} />
                                                    <LabeledNumber label="Port" value={db.port} onChange={(v) => setDb({ ...db, port: v })} />
                                                    <LabeledInput label="Database name" value={db.dbName} onChange={(v) => setDb({ ...db, dbName: v })} />
                                                    <LabeledInput label="Username" value={db.username} onChange={(v) => setDb({ ...db, username: v })} />
                                                    <LabeledInput label="Password" type="password" value={db.password} onChange={(v) => setDb({ ...db, password: v })} />
                                                    <div className="grid grid-cols-2 gap-3">
                                                        <LabeledNumber label="Pool min" value={db.poolMin} onChange={(v) => setDb({ ...db, poolMin: v })} />
                                                        <LabeledNumber label="Pool max" value={db.poolMax} onChange={(v) => setDb({ ...db, poolMax: v })} />
                                                    </div>
                                                </div>
                                            </div>
                                        )}

                                        <div className="rounded-md border p-3 space-y-2">
                                            <Label className="text-sm">Read replicas (optional)</Label>
                                            <Input placeholder="Comma-separated URLs" value={db.readReplicas} onChange={(e) => setDb({ ...db, readReplicas: e.target.value })} />
                                            <div className="text-xs text-muted-foreground">Example: <code>postgres://ro1…</code>, <code>postgres://ro2…</code></div>
                                        </div>

                                        <div className="rounded-md border p-3 space-y-3">
                                            <div className="font-medium">Table / Collection mappings</div>
                                            <div className="grid gap-3 md:grid-cols-3">
                                                {(["users", "roles", "sessions", "audit_logs", "devices", "policies", "email_queue"] as StorageDomain[]).map((k) => (
                                                    <LabeledInput
                                                        key={k}
                                                        label={k.replace("_", " ").replace("_", " ").replace(/\b\w/g, (s) => s.toUpperCase())}
                                                        value={db.mappings[k]}
                                                        onChange={(v) => setDb({ ...db, mappings: { ...db.mappings, [k]: v } })}
                                                    />
                                                ))}
                                            </div>
                                        </div>

                                        <div className="flex flex-wrap items-center justify-end gap-2">
                                            <Button variant="outline" onClick={() => push({ title: "Testing connection…", kind: "default" })}>
                                                Test connection
                                            </Button>
                                            <Button variant="outline" onClick={() => push({ title: "Schema migration planned", desc: "No destructive changes. (dry run)", kind: "default" })}>
                                                Dry-run migration
                                            </Button>
                                            <Button variant="success" onClick={() => push({ title: "Database settings saved", kind: "success" })}>
                                                Save database
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Storage (S3) */}
                            <TabsContent value="storage" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Storage</CardTitle>
                                        <CardDescription>Use S3-compatible storage instead of local storage for artifacts, exports, and backups.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3">
                                                    <Cloud className="h-4 w-4" />
                                                    <div className="font-medium">Backend</div>
                                                </div>
                                                <div className="flex items-center gap-3">
                                                    <Label className="text-sm">Use S3</Label>
                                                    <Switch checked={s3.backend === "s3"} onCheckedChange={(v) => setS3((prev) => ({ ...prev, backend: v ? "s3" : "local" }))} />
                                                </div>
                                            </div>

                                            {s3.backend === "s3" && (
                                                <div className="space-y-4">
                                                    <div className="grid gap-3 md:grid-cols-3">
                                                        <div className="grid gap-1">
                                                            <Label className="text-sm">Provider</Label>
                                                            <Select value={s3.provider} onValueChange={(v: S3Provider) => setS3({ ...s3, provider: v })}>
                                                                <SelectTrigger><SelectValue /></SelectTrigger>
                                                                <SelectContent>
                                                                    <SelectItem value="aws">AWS S3</SelectItem>
                                                                    <SelectItem value="minio">MinIO</SelectItem>
                                                                    <SelectItem value="wasabi">Wasabi</SelectItem>
                                                                    <SelectItem value="other">Other</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                        </div>
                                                        <LabeledInput label="Region" value={s3.region} onChange={(v) => setS3({ ...s3, region: v })} />
                                                        <LabeledInput label="Bucket" value={s3.bucket} onChange={(v) => setS3({ ...s3, bucket: v })} />
                                                        <LabeledInput label="Access Key ID" value={s3.accessKeyId} onChange={(v) => setS3({ ...s3, accessKeyId: v })} />
                                                        <LabeledInput label="Secret Access Key" type="password" value={s3.secretAccessKey} onChange={(v) => setS3({ ...s3, secretAccessKey: v })} />
                                                        <LabeledInput label="Endpoint (for MinIO/Other)" value={s3.endpoint} onChange={(v) => setS3({ ...s3, endpoint: v })} />
                                                        <LabeledInput label="Key prefix (optional)" value={s3.prefix} onChange={(v) => setS3({ ...s3, prefix: v })} />
                                                        <div className="flex items-center gap-4 mt-6">
                                                            <CheckToggle label="Path-style access" checked={s3.pathStyle} onChange={(v) => setS3({ ...s3, pathStyle: v })} />
                                                        </div>
                                                    </div>

                                                    <Separator />

                                                    <div className="grid gap-3 md:grid-cols-3">
                                                        <div className="grid gap-1">
                                                            <Label className="text-sm">Server-side encryption</Label>
                                                            <Select value={s3.sse} onValueChange={(v: "none" | "AES256" | "aws:kms") => setS3({ ...s3, sse: v })}>
                                                                <SelectTrigger><SelectValue /></SelectTrigger>
                                                                <SelectContent>
                                                                    <SelectItem value="none">None</SelectItem>
                                                                    <SelectItem value="AES256">AES256</SelectItem>
                                                                    <SelectItem value="aws:kms">AWS KMS</SelectItem>
                                                                </SelectContent>
                                                            </Select>
                                                        </div>
                                                        {s3.sse === "aws:kms" && (
                                                            <LabeledInput label="KMS Key ID (ARN)" value={s3.kmsKeyId} onChange={(v) => setS3({ ...s3, kmsKeyId: v })} />
                                                        )}
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        <div className="flex items-center justify-end gap-2">
                                            <Button variant="outline" onClick={() => push({ title: "Testing storage…", kind: "default" })}>
                                                Test storage
                                            </Button>
                                            <Button variant="success" onClick={() => push({ title: "Storage settings saved", kind: "success" })}>
                                                Save storage
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Backups */}
                            <TabsContent value="backups" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Backups</CardTitle>
                                        <CardDescription>Configure backup targets, schedule, retention and destination.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="rounded-md border p-3 space-y-3">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3">
                                                    <ArchiveRestore className="h-4 w-4" />
                                                    <div className="font-medium">Backup Configuration</div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <Switch checked={backups.enabled} onCheckedChange={(v) => setBackups({ ...backups, enabled: v })} />
                                                    <span className="text-sm">{backups.enabled ? "Enabled" : "Disabled"}</span>
                                                </div>
                                            </div>

                                            <div className="grid gap-2">
                                                <Label className="text-sm">Targets</Label>
                                                <div className="flex flex-wrap gap-2 text-sm">
                                                    {(["users", "roles", "devices", "policies", "audit_logs", "settings", "templates"] as BackupTarget[]).map((t) => (
                                                        <button
                                                            key={t}
                                                            type="button"
                                                            onClick={() => toggleTarget(t)}
                                                            className={cn(
                                                                "rounded border px-2 py-1 capitalize",
                                                                backups.targets.includes(t) ? "border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20" : "border-border"
                                                            )}
                                                        >
                                                            {t.replace("_", " ")}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>

                                            <div className="grid gap-3 md:grid-cols-3">
                                                <div className="grid gap-1">
                                                    <Label className="text-sm">Schedule</Label>
                                                    <Select value={backups.schedule} onValueChange={(v: "hourly" | "daily" | "weekly" | "cron") => setBackups({ ...backups, schedule: v })}>
                                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="hourly">Hourly</SelectItem>
                                                            <SelectItem value="daily">Daily</SelectItem>
                                                            <SelectItem value="weekly">Weekly</SelectItem>
                                                            <SelectItem value="cron">Custom (cron)</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>

                                                {backups.schedule === "cron" ? (
                                                    <LabeledInput label="Cron expression" value={backups.cronExpr} onChange={(v) => setBackups({ ...backups, cronExpr: v })} />
                                                ) : (
                                                    <div className="grid gap-1">
                                                        <Label className="text-sm">Next run (example)</Label>
                                                        <Input value="Tonight 03:00" readOnly />
                                                    </div>
                                                )}

                                                <LabeledNumber label="Retention (days)" value={backups.retentionDays} onChange={(v) => setBackups({ ...backups, retentionDays: v })} />
                                            </div>

                                            <div className="rounded-md border p-3 space-y-3">
                                                <div className="font-medium">Destination</div>
                                                <div className="grid gap-3 md:grid-cols-3">
                                                    <div className="grid gap-1">
                                                        <Label className="text-sm">Type</Label>
                                                        <Select
                                                            value={backups.destination.kind}
                                                            onValueChange={(v: "local" | "s3") =>
                                                                setBackups({ ...backups, destination: v === "local" ? { kind: "local" } : { kind: "s3", bucket: "", prefix: "" } })
                                                            }
                                                        >
                                                            <SelectTrigger><SelectValue /></SelectTrigger>
                                                            <SelectContent>
                                                                <SelectItem value="local">Local</SelectItem>
                                                                <SelectItem value="s3">S3</SelectItem>
                                                            </SelectContent>
                                                        </Select>
                                                    </div>

                                                    {backups.destination.kind === "s3" && (
                                                        <>
                                                            <LabeledInput
                                                                label="Bucket"
                                                                value={backups.destination.bucket}
                                                                onChange={(v) => setBackups({ ...backups, destination: { kind: "s3", bucket: v, prefix: (backups.destination as any).prefix ?? "" } })}
                                                            />
                                                            <LabeledInput
                                                                label="Prefix"
                                                                value={backups.destination.prefix}
                                                                onChange={(v) => setBackups({ ...backups, destination: { kind: "s3", bucket: (backups.destination as any).bucket ?? "", prefix: v } })}
                                                            />
                                                        </>
                                                    )}
                                                </div>

                                                <CheckToggle label="Encrypt backup archives" checked={backups.encrypt} onChange={(v) => setBackups({ ...backups, encrypt: v })} />
                                            </div>
                                        </div>

                                        <div className="rounded-md border">
                                            <div className="grid grid-cols-12 border-b bg-muted/30 p-2 text-xs font-medium text-muted-foreground">
                                                <div className="col-span-3 px-2">ID</div>
                                                <div className="col-span-3 px-2">Time</div>
                                                <div className="col-span-3 px-2">Status</div>
                                                <div className="col-span-3 px-2">Note</div>
                                            </div>
                                            {backupHistory.map((b) => (
                                                <div key={b.id} className="grid grid-cols-12 items-center border-b p-2 last:border-b-0 text-sm">
                                                    <div className="col-span-3 px-2 font-mono">{b.id}</div>
                                                    <div className="col-span-3 px-2">{b.at}</div>
                                                    <div className={cn("col-span-3 px-2", b.status === "success" ? "text-emerald-600" : b.status === "failed" ? "text-red-600" : "text-amber-600")}>
                                                        {b.status}
                                                    </div>
                                                    <div className="col-span-3 px-2 text-muted-foreground">{b.note ?? "—"}</div>
                                                </div>
                                            ))}
                                        </div>

                                        <div className="flex items-center justify-end gap-2">
                                            <Button
                                                variant="outline"
                                                onClick={() => {
                                                    const id = Math.random().toString(36).slice(2, 8);
                                                    setBackupHistory((prev) => [{ id, at: new Date().toISOString().slice(0, 16).replace("T", " "), status: "running" }, ...prev]);
                                                    push({ title: "Backup started", kind: "default" });
                                                }}
                                            >
                                                Run backup now
                                            </Button>
                                            <Button variant="success" onClick={() => push({ title: "Backup settings saved", kind: "success" })}>
                                                Save backup settings
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Email Templates */}
                            <TabsContent value="templates" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Email Templates</CardTitle>
                                        <CardDescription>Customize system email subjects & bodies. Variables like <code>{`{{first_name}}`}</code>, <code>{`{{org_name}}`}</code>, <code>{`{{invite_link}}`}</code>.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        {([
                                            { key: "invite", label: "Invite" },
                                            { key: "password_reset", label: "Password reset" },
                                            { key: "alert", label: "Alert" },
                                        ] as { key: TemplateKey; label: string }[]).map(({ key, label }) => (
                                            <div key={key} className="rounded-md border p-3 space-y-3">
                                                <div className="font-medium">{label}</div>
                                                <LabeledInput label="Subject" value={templates[key].subject} onChange={(v) => setTemplates((prev) => ({ ...prev, [key]: { ...prev[key], subject: v } }))} />
                                                <LabeledTextarea label="Body" value={templates[key].body} onChange={(v) => setTemplates((prev) => ({ ...prev, [key]: { ...prev[key], body: v } }))} rows={8} />
                                                <div className="flex justify-end gap-2">
                                                    <Button variant="outline" onClick={() => push({ title: `Test ${label} email sent`, kind: "success" })}>Send test</Button>
                                                    <Button variant="success" onClick={() => push({ title: `${label} template saved`, kind: "success" })}>Save {label.toLowerCase()}</Button>
                                                </div>
                                            </div>
                                        ))}
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Audit */}
                            <TabsContent value="audit" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Audit Logs</CardTitle>
                                        <CardDescription>Search and filter by category, severity, and date.</CardDescription>
                                    </CardHeader>

                                    <CardContent className="space-y-4">
                                        <div className="rounded-md border p-3">
                                            <div className="grid gap-3 md:grid-cols-5 items-end">
                                                <div className="md:col-span-2">
                                                    <Label className="text-sm" htmlFor="audit-search">Search</Label>
                                                    <div className="relative">
                                                        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                                                        <Input id="audit-search" placeholder="Search action, details, actor…" className="pl-8" value={auditQuery} onChange={(e) => setAuditQuery(e.target.value)} />
                                                    </div>
                                                </div>

                                                <div>
                                                    <Label className="text-sm">Category</Label>
                                                    <Select value={auditCategory} onValueChange={(v) => setAuditCategory(v as any)}>
                                                        <SelectTrigger><SelectValue placeholder="All categories" /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="all">All</SelectItem>
                                                            <SelectItem value="security">Security</SelectItem>
                                                            <SelectItem value="role">Role Changes</SelectItem>
                                                            <SelectItem value="user">User Management</SelectItem>
                                                            <SelectItem value="auth">Authentication</SelectItem>
                                                            <SelectItem value="email">Email</SelectItem>
                                                            <SelectItem value="device">Devices</SelectItem>
                                                            <SelectItem value="system">System</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>

                                                <div>
                                                    <Label className="text-sm">Severity</Label>
                                                    <Select value={auditSeverity} onValueChange={(v) => setAuditSeverity(v as any)}>
                                                        <SelectTrigger><SelectValue placeholder="All severities" /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="all">All</SelectItem>
                                                            <SelectItem value="info">Info</SelectItem>
                                                            <SelectItem value="warning">Warning</SelectItem>
                                                            <SelectItem value="error">Error</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>

                                                <div className="grid grid-cols-2 gap-2">
                                                    <div>
                                                        <Label className="text-sm" htmlFor="audit-from">From</Label>
                                                        <Input id="audit-from" type="date" value={auditFrom} onChange={(e) => setAuditFrom(e.target.value)} />
                                                    </div>
                                                    <div>
                                                        <Label className="text-sm" htmlFor="audit-to">To</Label>
                                                        <Input id="audit-to" type="date" value={auditTo} onChange={(e) => setAuditTo(e.target.value)} />
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-3 flex items-center justify-end">
                                                <Button variant="outline" onClick={exportAuditCsv}>Export CSV</Button>
                                            </div>
                                        </div>

                                        {filteredAudit.length === 0 ? (
                                            <div className="rounded-md border p-6 text-sm text-muted-foreground">No audit events match your filters.</div>
                                        ) : (
                                            <div className="space-y-6">
                                                {orderedCategories.map((cat) => {
                                                    const logs = groupedAudit[cat] ?? [];
                                                    if (!logs.length) return null;
                                                    return (
                                                        <section key={cat} className="space-y-3">
                                                            <div className="flex items-center justify-between">
                                                                <div className="text-sm font-semibold">{CATEGORY_LABELS[cat]}</div>
                                                                <div className="text-xs text-muted-foreground">{logs.length} event{logs.length !== 1 ? "s" : ""}</div>
                                                            </div>

                                                            <div className="space-y-2">
                                                                {logs.map((e) => (
                                                                    <div key={e.id} className="rounded-md border p-3 text-sm">
                                                                        <div className="flex items-center justify-between">
                                                                            <div className="font-medium">{e.action}</div>
                                                                            <div className="text-xs text-muted-foreground">{e.at}</div>
                                                                        </div>
                                                                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs">
                                                                            <span className="rounded border px-1.5 py-0.5">{CATEGORY_LABELS[e.category]}</span>
                                                                            <span
                                                                                className={cn(
                                                                                    "rounded border px-1.5 py-0.5",
                                                                                    e.severity === "error"
                                                                                        ? "border-red-300 bg-red-50 dark:border-red-700 dark:bg-red-900/20"
                                                                                        : e.severity === "warning"
                                                                                            ? "border-amber-300 bg-amber-50 dark:border-amber-600 dark:bg-amber-900/20"
                                                                                            : "border-muted bg-muted/20"
                                                                                )}
                                                                            >
                                                                                {SEVERITY_LABELS[e.severity]}
                                                                            </span>
                                                                            <span className="text-muted-foreground">
                                                                                Actor: <span className="font-medium">{e.actor}</span>
                                                                            </span>
                                                                        </div>
                                                                        {e.details && <div className="mt-2 text-muted-foreground">{e.details}</div>}
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </section>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* API */}
                            <TabsContent value="api" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>API & Webhooks</CardTitle>
                                        <CardDescription>Keys, scopes, rate limits, webhooks, and allowed origins.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="rounded-md border p-3 space-y-3">
                                            <div className="font-medium">Create API Key</div>
                                            <div className="grid gap-3 md:grid-cols-3">
                                                <LabeledInput label="Label" value={newKeyLabel} onChange={setNewKeyLabel} />
                                                <div className="grid gap-1">
                                                    <Label className="text-sm">Type</Label>
                                                    <Select value={newKeyType} onValueChange={(v: "service" | "personal") => setNewKeyType(v)}>
                                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                                        <SelectContent>
                                                            <SelectItem value="service">Service account</SelectItem>
                                                            <SelectItem value="personal">Personal access token</SelectItem>
                                                        </SelectContent>
                                                    </Select>
                                                </div>
                                                <LabeledNumber label="Rate limit (rpm, optional)" value={newKeyRate} onChange={setNewKeyRate} />
                                            </div>

                                            <div className="grid gap-2">
                                                <Label className="text-sm">Scopes</Label>
                                                <div className="flex flex-wrap gap-2 text-sm">
                                                    {(["read:devices", "write:devices", "read:users", "write:users", "read:audit", "admin:roles", "admin:flags"] as ApiKeyScope[]).map((s) => (
                                                        <button
                                                            key={s}
                                                            type="button"
                                                            onClick={() => toggleScope(s)}
                                                            className={cn("rounded border px-2 py-1", newKeyScopes.includes(s) ? "border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20" : "border-border")}
                                                            title={s}
                                                        >
                                                            {s}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>

                                            <LabeledInput label="IP allowlist (comma-separated CIDRs, optional)" value={newKeyIps} onChange={setNewKeyIps} placeholder="192.168.1.0/24, 203.0.113.10/32" />

                                            <div className="text-right">
                                                <Button variant="success" onClick={createApiKey}>Create key</Button>
                                            </div>

                                            {revealKeyId && (
                                                <div className="rounded-md border p-3 text-sm">
                                                    <div className="font-medium mb-1">New key (copy now)</div>
                                                    <div className="text-muted-foreground">
                                                        {apiKeys.find((k) => k.id === revealKeyId)?.prefix}
                                                        ••••••••••••••••••••••
                                                    </div>
                                                    <div className="text-xs mt-1">For security, this token will not be shown again.</div>
                                                </div>
                                            )}
                                        </div>

                                        <div className="rounded-md border">
                                            <div className="grid grid-cols-12 border-b bg-muted/30 p-2 text-xs font-medium text-muted-foreground">
                                                <div className="col-span-3 px-2">Label</div>
                                                <div className="col-span-2 px-2">Prefix</div>
                                                <div className="col-span-3 px-2">Scopes</div>
                                                <div className="col-span-1 px-2">RPM</div>
                                                <div className="col-span-2 px-2">Last used</div>
                                                <div className="col-span-1 px-2 text-right">Actions</div>
                                            </div>
                                            {apiKeys.map((k) => (
                                                <div key={k.id} className="grid grid-cols-12 items-center border-b p-2 last:border-b-0 text-sm">
                                                    <div className="col-span-3 px-2">
                                                        {k.label} <span className="ml-2 text-xs rounded border px-1 py-0.5">{k.type}</span>
                                                    </div>
                                                    <div className="col-span-2 px-2 font-mono">{k.prefix}</div>
                                                    <div className="col-span-3 px-2 truncate">{k.scopes.join(", ")}</div>
                                                    <div className="col-span-1 px-2">{k.rateLimitRpm ?? "—"}</div>
                                                    <div className="col-span-2 px-2 text-muted-foreground">{k.lastUsedAt ?? "—"}</div>
                                                    <div className="col-span-1 px-2 text-right">
                                                        <Button variant="outline" size="sm" onClick={() => setRevealKeyId(k.id)}>Reveal</Button>{" "}
                                                        <Button variant="destructive" size="sm" onClick={() => revokeKey(k.id)}>Revoke</Button>
                                                    </div>
                                                    {k.ipAllowlist?.length ? (
                                                        <div className="col-span-12 px-2 pb-2 text-xs text-muted-foreground">IPs: {k.ipAllowlist.join(", ")}</div>
                                                    ) : null}
                                                </div>
                                            ))}
                                        </div>

                                        <div className="rounded-md border p-3 space-y-3">
                                            <div className="font-medium">Webhooks</div>
                                            <LabeledInput label="Signing secret" value={webhookSecret} onChange={setWebhookSecret} />
                                            <div className="flex gap-2">
                                                <Button variant="outline" onClick={rotateWebhookSecret}>Rotate secret</Button>
                                                <Button variant="outline" onClick={() => push({ title: "Test event sent", kind: "success" })}>Send test event</Button>
                                            </div>
                                            <div className="grid gap-2">
                                                <Label className="text-sm">Subscribed events</Label>
                                                <div className="flex flex-wrap gap-2 text-sm">
                                                    {["device.created", "device.updated", "alert.fired", "invite.sent", "email.failed"].map((ev) => (
                                                        <button
                                                            key={ev}
                                                            type="button"
                                                            onClick={() => setWebhookEvents((prev) => (prev.includes(ev) ? prev.filter((e) => e !== ev) : [...prev, ev]))}
                                                            className={cn("rounded border px-2 py-1", webhookEvents.includes(ev) ? "border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20" : "border-border")}
                                                        >
                                                            {ev}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>

                                        <div className="rounded-md border p-3 space-y-2">
                                            <div className="font-medium">CORS / Allowed Origins</div>
                                            <LabeledInput label="Origins (comma-separated)" value={allowedOrigins} onChange={setAllowedOrigins} placeholder="https://app.example.com, https://admin.example.com" />
                                        </div>

                                        <div className="rounded-md border p-3 space-y-2">
                                            <div className="font-medium">Quickstart</div>
                                            <div className="text-xs text-muted-foreground">Example curl:</div>
                                            <pre className="overflow-x-auto rounded bg-muted p-3 text-xs">
                                                <code>{`curl -H "Authorization: Bearer rk_live_xxx" \\\n  https://api.remoteiq.local/v1/devices`}</code>
                                            </pre>
                                        </div>

                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "API configuration saved", kind: "success" })}>
                                                Save API settings
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Feature Flags */}
                            <TabsContent value="flags" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Feature Flags</CardTitle>
                                        <CardDescription>Toggle preview features for your organization.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-3">
                                        <FlagRow label="New device grid" defaultChecked />
                                        <FlagRow label="Faster search pipeline" />
                                        <FlagRow label="Agent live stream" />
                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Flags updated", kind: "success" })}>
                                                Save flags
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* ======================================================================================= */}
                            {/* ================================= START: NEW TABS ===================================== */}
                            {/* ======================================================================================= */}

                            {/* Branding / Appearance */}
                            <TabsContent value="branding" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Branding & Appearance</CardTitle>
                                        <CardDescription>Customize logos, colors, and other visual elements of the application.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid md:grid-cols-2 gap-6">
                                            <SettingCard icon={<Palette className="h-4 w-4" />} title="Colors" desc="Define primary and secondary colors.">
                                                <div className="grid grid-cols-2 gap-4">
                                                    <LabeledInput label="Primary Color" type="color" value={branding.primaryColor} onChange={v => setBranding(b => ({ ...b, primaryColor: v }))} />
                                                    <LabeledInput label="Secondary Color" type="color" value={branding.secondaryColor} onChange={v => setBranding(b => ({ ...b, secondaryColor: v }))} />
                                                </div>
                                            </SettingCard>

                                            <SettingCard icon={<Upload className="h-4 w-4" />} title="Logos & Favicon" desc="Upload your company logos for light/dark themes.">
                                                <div className="space-y-3">
                                                    <div>
                                                        <Label className="text-sm">Main Logo (for light backgrounds)</Label>
                                                        <Input type="file" />
                                                    </div>
                                                    <div>
                                                        <Label className="text-sm">Inverse Logo (for dark backgrounds)</Label>
                                                        <Input type="file" />
                                                    </div>
                                                    <div>
                                                        <Label className="text-sm">Favicon (.ico)</Label>
                                                        <Input type="file" />
                                                    </div>
                                                </div>
                                            </SettingCard>
                                        </div>

                                        <Separator />

                                        <LabeledTextarea label="Email Header HTML" value={branding.emailHeader} onChange={v => setBranding(b => ({ ...b, emailHeader: v }))} rows={5} />
                                        <LabeledTextarea label="Email Footer HTML" value={branding.emailFooter} onChange={v => setBranding(b => ({ ...b, emailFooter: v }))} rows={5} />

                                        <Separator />

                                        <LabeledTextarea label="Custom CSS" value={branding.customCss} onChange={v => setBranding(b => ({ ...b, customCss: v }))} rows={10} />

                                        <Separator />

                                        <CheckToggle label="Allow clients to toggle light/dark theme in portal" checked={branding.allowClientThemeToggle} onChange={v => setBranding(b => ({ ...b, allowClientThemeToggle: v }))} />

                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Branding settings saved", kind: "success" })}>
                                                Save Branding
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Localization */}
                            <TabsContent value="localization" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Localization & Regional Settings</CardTitle>
                                        <CardDescription>Configure language, time zone, and formatting for dates and numbers.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid gap-3 md:grid-cols-3">
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Default Language</Label>
                                                <Select value={localization.language} onValueChange={(v: LocalizationSettings['language']) => setLocalization(l => ({ ...l, language: v }))}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="en-US">English (US)</SelectItem>
                                                        <SelectItem value="en-GB">English (UK)</SelectItem>
                                                        <SelectItem value="es-ES">Spanish</SelectItem>
                                                        <SelectItem value="fr-FR">French</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Time Zone</Label>
                                                <Select value={localization.timeZone} onValueChange={v => setLocalization(l => ({ ...l, timeZone: v }))}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="America/New_York">Eastern Time (US & Canada)</SelectItem>
                                                        <SelectItem value="America/Chicago">Central Time (US & Canada)</SelectItem>
                                                        <SelectItem value="America/Los_Angeles">Pacific Time (US & Canada)</SelectItem>
                                                        <SelectItem value="Europe/London">London (GMT)</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="grid gap-1">
                                                <Label className="text-sm">First Day of Week</Label>
                                                <Select value={localization.firstDayOfWeek} onValueChange={(v: LocalizationSettings['firstDayOfWeek']) => setLocalization(l => ({ ...l, firstDayOfWeek: v }))}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="sunday">Sunday</SelectItem>
                                                        <SelectItem value="monday">Monday</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Date Format</Label>
                                                <Select value={localization.dateFormat} onValueChange={(v: LocalizationSettings['dateFormat']) => setLocalization(l => ({ ...l, dateFormat: v }))}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                                                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                                                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Time Format</Label>
                                                <Select value={localization.timeFormat} onValueChange={(v: LocalizationSettings['timeFormat']) => setLocalization(l => ({ ...l, timeFormat: v }))}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="12h">12-hour</SelectItem>
                                                        <SelectItem value="24h">24-hour</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                            <div className="grid gap-1">
                                                <Label className="text-sm">Number Format</Label>
                                                <Select value={localization.numberFormat} onValueChange={(v: LocalizationSettings['numberFormat']) => setLocalization(l => ({ ...l, numberFormat: v }))}>
                                                    <SelectTrigger><SelectValue /></SelectTrigger>
                                                    <SelectContent>
                                                        <SelectItem value="1,234.56">1,234.56</SelectItem>
                                                        <SelectItem value="1.234,56">1.234,56</SelectItem>
                                                    </SelectContent>
                                                </Select>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Localization settings saved", kind: "success" })}>
                                                Save Localization
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Notifications (Email/SMS/Push) */}
                            <TabsContent value="notifications" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Notifications</CardTitle>
                                        <CardDescription>Define rules for routing alerts and notifications to different channels like Email, SMS, Slack, and more.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="flex justify-end">
                                            <Button variant="success"><Plus className="mr-2 h-4 w-4" /> Add Rule</Button>
                                        </div>
                                        <div className="rounded-md border">
                                            <div className="grid grid-cols-12 border-b bg-muted/30 p-2 text-xs font-medium text-muted-foreground">
                                                <div className="col-span-4 px-2">Event</div>
                                                <div className="col-span-1 px-2">Severity</div>
                                                <div className="col-span-4 px-2">Channels & Recipients</div>
                                                <div className="col-span-3 px-2 text-right">Actions</div>
                                            </div>
                                            {notifications.map((rule) => (
                                                <div key={rule.id} className="grid grid-cols-12 items-center border-b p-2 text-sm last:border-b-0">
                                                    <div className="col-span-4 px-2 font-medium">{rule.event}</div>
                                                    <div className="col-span-1 px-2 capitalize">{rule.severity}</div>
                                                    <div className="col-span-4 px-2 text-muted-foreground">
                                                        <div className="flex flex-wrap gap-1">
                                                            {rule.channels.map(c => <span key={c} className="rounded border px-1.5 py-0.5 text-xs capitalize">{c}</span>)}
                                                        </div>
                                                        <div className="mt-1 text-xs truncate">{rule.recipients}</div>
                                                    </div>
                                                    <div className="col-span-3 px-2 flex items-center justify-end gap-2">
                                                        <Switch checked={rule.enabled} />
                                                        <Button variant="outline" size="sm">Edit</Button>
                                                        <Button variant="destructive" size="sm">Delete</Button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Notification settings saved", kind: "success" })}>
                                                Save Notifications
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Security Policies */}
                            <TabsContent value="security_policies" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Security Policies</CardTitle>
                                        <CardDescription>Enforce password strength, session timeouts, and network restrictions.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <Card>
                                            <CardHeader>
                                                <CardTitle className="text-base">Password Policy</CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                                                    <LabeledNumber label="Minimum length" value={secPolicies.passwordMinLength} onChange={v => setSecPolicies(s => ({ ...s, passwordMinLength: v }))} />
                                                    <LabeledNumber label="Password history (prevent reuse)" value={secPolicies.passwordHistory} onChange={v => setSecPolicies(s => ({ ...s, passwordHistory: v }))} />
                                                </div>
                                                <div className="flex flex-wrap gap-x-6 gap-y-2">
                                                    <CheckToggle label="Require numbers" checked={secPolicies.passwordRequireNumbers} onChange={v => setSecPolicies(s => ({ ...s, passwordRequireNumbers: v }))} />
                                                    <CheckToggle label="Require special characters" checked={secPolicies.passwordRequireSpecial} onChange={v => setSecPolicies(s => ({ ...s, passwordRequireSpecial: v }))} />
                                                    <CheckToggle label="Require uppercase letters" checked={secPolicies.passwordRequireUppercase} onChange={v => setSecPolicies(s => ({ ...s, passwordRequireUppercase: v }))} />
                                                </div>
                                            </CardContent>
                                        </Card>
                                        <Card>
                                            <CardHeader>
                                                <CardTitle className="text-base">Session & Network</CardTitle>
                                            </CardHeader>
                                            <CardContent className="space-y-4">
                                                <div className="grid md:grid-cols-2 gap-4">
                                                    <LabeledNumber label="Session timeout (minutes)" value={secPolicies.sessionTimeoutMins} onChange={v => setSecPolicies(s => ({ ...s, sessionTimeoutMins: v }))} />
                                                    <LabeledNumber label="Idle lock screen (minutes)" value={secPolicies.idleLockMins} onChange={v => setSecPolicies(s => ({ ...s, idleLockMins: v }))} />
                                                </div>
                                                <LabeledTextarea label="IP Allowlist (CIDR, one per line)" value={secPolicies.ipAllowlist} onChange={v => setSecPolicies(s => ({ ...s, ipAllowlist: v }))} rows={5} />
                                                <CheckToggle label="Enable CAPTCHA on login" checked={secPolicies.enableCaptcha} onChange={v => setSecPolicies(s => ({ ...s, enableCaptcha: v }))} />
                                            </CardContent>
                                        </Card>
                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Security policies saved", kind: "success" })}>
                                                Save Policies
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Integrations */}
                            <TabsContent value="integrations" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Integrations</CardTitle>
                                        <CardDescription>Connect RemoteIQ to other services like Slack, Jira, and ServiceNow.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                                            {integrations.map(integ => (
                                                <Card key={integ.id}>
                                                    <CardHeader className="flex flex-row items-center justify-between pb-2">
                                                        <CardTitle className="text-sm font-medium">{integ.name}</CardTitle>
                                                        {integ.id === 'slack' ? <Slack className="h-4 w-4 text-muted-foreground" /> : <Plug className="h-4 w-4 text-muted-foreground" />}
                                                    </CardHeader>
                                                    <CardContent>
                                                        <div className="text-xs text-muted-foreground mb-4">{integ.connected ? 'Connected' : 'Not connected'}</div>
                                                        <Button variant={integ.connected ? 'destructive' : 'default'} className="w-full">
                                                            {integ.connected ? 'Disconnect' : 'Connect'}
                                                        </Button>
                                                    </CardContent>
                                                </Card>
                                            ))}
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Subscription & Licensing */}
                            <TabsContent value="subscription" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Subscription & Licensing</CardTitle>
                                        <CardDescription>Manage your plan, seat usage, and license keys.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="rounded-md border p-4 grid md:grid-cols-2 gap-4">
                                            <div>
                                                <div className="text-sm text-muted-foreground">Current Plan</div>
                                                <div className="text-xl font-bold">{subscription.plan}</div>
                                            </div>
                                            <div>
                                                <div className="text-sm text-muted-foreground">Renewal Date</div>
                                                <div className="text-xl font-bold">{subscription.renewalDate}</div>
                                            </div>
                                            <div>
                                                <div className="text-sm text-muted-foreground">Seats</div>
                                                <div className="text-xl font-bold">{subscription.seatsUsed} / {subscription.seatsTotal}</div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                <Button>Manage Billing</Button>
                                                <Button variant="outline">Add Seats</Button>
                                            </div>
                                        </div>
                                        <LabeledInput label="License Key (for on-prem agents)" value={subscription.licenseKey} onChange={v => setSubscription(s => ({ ...s, licenseKey: v }))} />
                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Subscription settings saved", kind: "success" })}>
                                                Save License
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Client Portal */}
                            <TabsContent value="client_portal" className="mt-0">
                                <Card>
                                    <CardHeader>
                                        <CardTitle>Client Portal Settings</CardTitle>
                                        <CardDescription>Configure what your clients can see and do in their portal.</CardDescription>
                                    </CardHeader>
                                    <CardContent className="space-y-6">
                                        <div className="grid md:grid-cols-2 gap-6">
                                            <div className="space-y-2">
                                                <Label>Enabled Modules</Label>
                                                <CheckToggle label="Dashboard" checked={clientPortal.enabledModules.includes('dashboard')} onChange={() => toggleClientPortalModule('dashboard')} />
                                                <CheckToggle label="Tickets" checked={clientPortal.enabledModules.includes('tickets')} onChange={() => toggleClientPortalModule('tickets')} />
                                                <CheckToggle label="Devices" checked={clientPortal.enabledModules.includes('devices')} onChange={() => toggleClientPortalModule('devices')} />
                                                <CheckToggle label="Invoices & Billing" checked={clientPortal.enabledModules.includes('invoices')} onChange={() => toggleClientPortalModule('invoices')} />
                                                <CheckToggle label="Reports" checked={clientPortal.enabledModules.includes('reports')} onChange={() => toggleClientPortalModule('reports')} />
                                            </div>
                                            <div className="space-y-2">
                                                <Label>Other Settings</Label>
                                                <CheckToggle label="Show SLA Information" checked={clientPortal.showSla} onChange={v => setClientPortal(cp => ({ ...cp, showSla: v }))} />
                                                <Label className="mt-4 block">Allowed Contact Methods</Label>
                                                <CheckToggle label="Portal Tickets" checked={clientPortal.contactMethods.includes('portal')} onChange={() => toggleClientPortalContact('portal')} />
                                                <CheckToggle label="Email" checked={clientPortal.contactMethods.includes('email')} onChange={() => toggleClientPortalContact('email')} />
                                                <CheckToggle label="Phone" checked={clientPortal.contactMethods.includes('phone')} onChange={() => toggleClientPortalContact('phone')} />
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <Button variant="success" onClick={() => push({ title: "Client portal settings saved", kind: "success" })}>
                                                Save Portal Settings
                                            </Button>
                                        </div>
                                    </CardContent>
                                </Card>
                            </TabsContent>

                            {/* Dummy Placeholders for Remaining Tabs */}
                            {["compliance", "agents", "workflows", "import_export", "custom_fields", "sla", "ticketing", "secrets", "sessions", "roles_matrix", "migrations", "reports", "support"].map(tabName => (
                                <TabsContent key={tabName} value={tabName} className="mt-0">
                                    <Card>
                                        <CardHeader>
                                            <CardTitle className="capitalize">{tabName.replace(/_/g, ' ')}</CardTitle>
                                            <CardDescription>Configuration for {tabName.replace(/_/g, ' ')}. This is a placeholder UI.</CardDescription>
                                        </CardHeader>
                                        <CardContent>
                                            <div className="flex items-center justify-center h-48 rounded-md border-2 border-dashed">
                                                <p className="text-muted-foreground">{tabName.replace(/_/g, ' ')} UI goes here.</p>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </TabsContent>
                            ))}

                        </div>
                    </div>
                </Tabs>
            </div>

            {/* Invite Users Modal */}
            <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Invite users</DialogTitle>
                        <DialogDescription>Enter one or more email addresses, separated by commas.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-2">
                        <Label htmlFor="invite-emails">Email addresses</Label>
                        <Input id="invite-emails" placeholder="alice@acme.com, bob@acme.com" value={inviteEmails} onChange={(e) => setInviteEmails(e.target.value)} />
                    </div>
                    <DialogFooter className="mt-4">
                        <Button variant="outline" onClick={() => setInviteOpen(false)}>Cancel</Button>
                        <Button variant="success" onClick={onInviteUsers}>Send invites</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Confirm Remove User */}
            <Dialog open={!!removeUserId} onOpenChange={() => setRemoveUserId(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Delete user?</DialogTitle>
                    </DialogHeader>
                    <DialogDescription className="text-red-600 dark:text-red-400">This action is permanent and cannot be undone.</DialogDescription>
                    <div className="text-sm">Are you sure you want to delete this user from your organization?</div>
                    <DialogFooter className="mt-4">
                        <Button variant="outline" onClick={() => setRemoveUserId(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={onConfirmRemoveUser}>Delete user</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Reset 2FA */}
            <Dialog open={!!reset2FAUserId} onOpenChange={() => setReset2FAUserId(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Reset 2FA for user?</DialogTitle>
                        <DialogDescription className="text-amber-600 dark:text-amber-400">
                            This will invalidate their current 2FA device and require re-enrollment at next sign-in.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="text-sm">Are you sure you want to reset two-factor authentication for this user?</div>
                    <DialogFooter className="mt-4">
                        <Button variant="outline" onClick={() => setReset2FAUserId(null)}>Cancel</Button>
                        <Button
                            variant="destructive"
                            onClick={() => {
                                const u = users.find((x) => x.id === reset2FAUserId);
                                setReset2FAUserId(null);
                                push({ title: "2FA reset", kind: "success", desc: u ? `User: ${u.email}` : undefined });
                            }}
                        >
                            Reset 2FA
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* Delete Role */}
            <Dialog open={!!deleteRoleId} onOpenChange={() => setDeleteRoleId(null)}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Delete role?</DialogTitle>
                        <DialogDescription className="text-red-600 dark:text-red-400">
                            Users assigned to this role will lose its permissions.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="text-sm">Are you sure you want to delete this role?</div>
                    <DialogFooter className="mt-4">
                        <Button variant="outline" onClick={() => setDeleteRoleId(null)}>Cancel</Button>
                        <Button variant="destructive" onClick={confirmDeleteRole}>Delete role</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {/* toasts */}
            <div className="fixed bottom-4 right-4 z-[100] space-y-2">
                {toasts.map((t) => {
                    const klass =
                        t.kind === "success"
                            ? "border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-200"
                            : t.kind === "destructive"
                                ? "border-red-200 bg-red-50 text-red-900 dark:border-red-700 dark:bg-red-900/20 dark:text-red-200"
                                : t.kind === "warning"
                                    ? "border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-600 dark:bg-amber-900/20 dark:text-amber-200"
                                    : "border-border bg-card text-card-foreground";
                    return (
                        <div key={t.id} className={cn("w-[340px] rounded-md border px-4 py-3 shadow-md", klass)}>
                            <div className="text-sm font-medium">{t.title}</div>
                            {t.desc && <div className="mt-1 text-xs/5 opacity-90">{t.desc}</div>}
                        </div>
                    );
                })}
            </div>
        </main>
    );
}

/* ===== Reusable UI helpers ===== */
function PermRow({ label, checked, onChecked }: { label: string; checked: boolean; onChecked: () => void }) {
    return (
        <label className="flex items-center justify-between rounded-md border p-2">
            <span className="text-sm">{label}</span>
            <Switch checked={checked} onCheckedChange={onChecked} />
        </label>
    );
}

function SettingCard({ icon, title, desc, children }: { icon: React.ReactNode; title: string; desc: string; children: React.ReactNode }) {
    return (
        <div className="rounded-md border p-3">
            <div className="mb-2 flex items-center gap-2">
                {icon}
                <div className="font-medium">{title}</div>
            </div>
            <div className="text-xs text-muted-foreground mb-3">{desc}</div>
            {children}
        </div>
    );
}

function FlagRow({ label, defaultChecked = false }: { label: string; defaultChecked?: boolean }) {
    return (
        <div className="flex items-center justify-between rounded-md border p-3">
            <div className="flex items-center gap-2">
                <Bug className="h-4 w-4" />
                <span className="text-sm">{label}</span>
            </div>
            <Switch defaultChecked={defaultChecked} />
        </div>
    );
}

function LabeledInput({
    label,
    value,
    onChange,
    type = "text",
    placeholder,
    className,
}: {
    label: string;
    value: string;
    onChange: (v: string) => void;
    type?: string;
    placeholder?: string;
    className?: string;
}) {
    return (
        <div className={cn("grid gap-1", className)}>
            <Label className="text-sm">{label}</Label>
            <Input value={value} onChange={(e) => onChange(e.target.value)} type={type} placeholder={placeholder} />
        </div>
    );
}

function LabeledTextarea({ label, value, onChange, rows = 6 }: { label: string; value: string; onChange: (v: string) => void; rows?: number }) {
    return (
        <div className="grid gap-1">
            <Label className="text-sm">{label}</Label>
            <Textarea value={value} onChange={(e) => onChange(e.target.value)} rows={rows} />
        </div>
    );
}

function LabeledNumber({ label, value, onChange }: { label: string; value: number | ""; onChange: (v: number | "") => void }) {
    return (
        <div className="grid gap-1">
            <Label className="text-sm">{label}</Label>
            <Input
                inputMode="numeric"
                value={value}
                onChange={(e) => {
                    const v = e.target.value;
                    onChange(v === "" ? "" : Number(v));
                }}
            />
        </div>
    );
}

function CheckToggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
    return (
        <label className="inline-flex items-center gap-2">
            <Switch checked={checked} onCheckedChange={onChange} />
            <span className="text-sm">{label}</span>
        </label>
    );
}