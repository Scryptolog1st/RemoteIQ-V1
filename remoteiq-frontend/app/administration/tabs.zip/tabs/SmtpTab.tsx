"use client";

import * as React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TabsContent } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Mail, Globe, Bell, TestTube2 } from "lucide-react";
import { EmailPurpose, EmailProfile, SmtpSettings, ImapSettings, PopSettings, ToastFn } from "../types";
import { LabeledInput, LabeledNumber, CheckToggle } from "../helpers";

interface SmtpTabProps {
    push: ToastFn;
}

export default function SmtpTab({ push }: SmtpTabProps) {
    const [activePurpose, setActivePurpose] = React.useState<EmailPurpose>("alerts");
    const [emailProfiles, setEmailProfiles] = React.useState<Record<EmailPurpose, EmailProfile>>({
        alerts: {
            enabled: true,
            smtp: { host: "smtp.example.com", port: 587, username: "alerts@example.com", password: "", useTLS: true, useSSL: false, fromAddress: "alerts@your-msp.com" },
            imap: { host: "imap.example.com", port: 993, username: "alerts@example.com", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
        invites: {
            enabled: true,
            smtp: { host: "smtp.example.com", port: 587, username: "invites@example.com", password: "", useTLS: true, useSSL: false, fromAddress: "invites@your-msp.com" },
            imap: { host: "imap.example.com", port: 993, username: "invites@example.com", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
        password_resets: {
            enabled: true,
            smtp: { host: "smtp.example.com", port: 587, username: "passwords@example.com", password: "", useTLS: true, useSSL: false, fromAddress: "passwords@your-msp.com" },
            imap: { host: "imap.example.com", port: 993, username: "passwords@example.com", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
        reports: {
            enabled: false,
            smtp: { host: "", port: "", username: "", password: "", useTLS: true, useSSL: false, fromAddress: "reports@your-msp.com" },
            imap: { host: "", port: "", username: "", password: "", useSSL: true },
            pop: { host: "", port: "", username: "", password: "", useSSL: true },
        },
    });

    function updateProfile<K extends keyof EmailProfile>(purpose: EmailPurpose, key: K, value: EmailProfile[K]) {
        setEmailProfiles((prev) => ({ ...prev, [purpose]: { ...prev[purpose], [key]: value } }));
    }
    function updateSmtp(purpose: EmailPurpose, partial: Partial<SmtpSettings>) {
        const current = emailProfiles[purpose].smtp;
        updateProfile(purpose, "smtp", { ...current, ...partial });
    }
    function updateImap(purpose: EmailPurpose, partial: Partial<ImapSettings>) {
        const current = emailProfiles[purpose].imap;
        updateProfile(purpose, "imap", { ...current, ...partial });
    }
    function updatePop(purpose: EmailPurpose, partial: Partial<PopSettings>) {
        const current = emailProfiles[purpose].pop;
        updateProfile(purpose, "pop", { ...current, ...partial });
    }
    function saveEmailSettings() {
        push({ title: "SMTP settings saved", kind: "success", desc: `${activePurpose} profile` });
    }
    function testConnections() {
        push({ title: "Connection tests started", kind: "default", desc: `Testing ${activePurpose} (SMTP/IMAP/POP)` });
        setTimeout(() => push({ title: "SMTP OK • IMAP OK • POP OK", kind: "success", desc: `${activePurpose} profile` }), 900);
    }

    return (
        <TabsContent value="smtp" className="mt-0">
            <Card>
                <CardHeader>
                    <CardTitle>SMTP Settings</CardTitle>
                    <CardDescription>Configure SMTP/IMAP/POP per purpose (Alerts, Invites, Password Resets, Reports).</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="flex flex-wrap items-center gap-2">
                        <Label className="text-sm">Purpose</Label>
                        <Select value={activePurpose} onValueChange={(v: EmailPurpose) => setActivePurpose(v)}>
                            <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
                            <SelectContent>
                                <SelectItem value="alerts">Alerts</SelectItem>
                                <SelectItem value="invites">Invites</SelectItem>
                                <SelectItem value="password_resets">Password Resets</SelectItem>
                                <SelectItem value="reports">Reports</SelectItem>
                            </SelectContent>
                        </Select>
                        <div className="flex items-center gap-2 ml-auto">
                            <Switch checked={emailProfiles[activePurpose].enabled} onCheckedChange={(v) => updateProfile(activePurpose, "enabled", v)} />
                            <span className="text-sm">{emailProfiles[activePurpose].enabled ? "Enabled" : "Disabled"}</span>
                        </div>
                    </div>

                    <Separator />

                    {/* SMTP */}
                    <section className="space-y-3">
                        <div className="flex items-center gap-2">
                            <Mail className="h-4 w-4" />
                            <h3 className="font-medium">SMTP</h3>
                        </div>
                        <div className="grid gap-3 md:grid-cols-3">
                            <LabeledInput label="Host" value={emailProfiles[activePurpose].smtp.host} onChange={(v) => updateSmtp(activePurpose, { host: v })} />
                            <LabeledNumber label="Port" value={emailProfiles[activePurpose].smtp.port} onChange={(v) => updateSmtp(activePurpose, { port: v })} />
                            <LabeledInput label="From Address" value={emailProfiles[activePurpose].smtp.fromAddress} onChange={(v) => updateSmtp(activePurpose, { fromAddress: v })} />
                            <LabeledInput label="Username" value={emailProfiles[activePurpose].smtp.username} onChange={(v) => updateSmtp(activePurpose, { username: v })} />
                            <LabeledInput label="Password" type="password" value={emailProfiles[activePurpose].smtp.password} onChange={(v) => updateSmtp(activePurpose, { password: v })} />
                            <div className="flex items-center gap-6 mt-6">
                                <CheckToggle label="Use TLS (STARTTLS)" checked={emailProfiles[activePurpose].smtp.useTLS} onChange={(v) => updateSmtp(activePurpose, { useTLS: v })} />
                                <CheckToggle label="Use SSL" checked={emailProfiles[activePurpose].smtp.useSSL} onChange={(v) => updateSmtp(activePurpose, { useSSL: v })} />
                            </div>
                        </div>
                    </section>

                    <Separator />

                    {/* IMAP */}
                    <section className="space-y-3">
                        <div className="flex items-center gap-2">
                            <Globe className="h-4 w-4" />
                            <h3 className="font-medium">IMAP</h3>
                        </div>
                        <div className="grid gap-3 md:grid-cols-3">
                            <LabeledInput label="Host" value={emailProfiles[activePurpose].imap.host} onChange={(v) => updateImap(activePurpose, { host: v })} />
                            <LabeledNumber label="Port" value={emailProfiles[activePurpose].imap.port} onChange={(v) => updateImap(activePurpose, { port: v })} />
                            <div className="flex items-center gap-6 mt-6">
                                <CheckToggle label="Use SSL" checked={emailProfiles[activePurpose].imap.useSSL} onChange={(v) => updateImap(activePurpose, { useSSL: v })} />
                            </div>
                            <LabeledInput label="Username" value={emailProfiles[activePurpose].imap.username} onChange={(v) => updateImap(activePurpose, { username: v })} />
                            <LabeledInput label="Password" type="password" value={emailProfiles[activePurpose].imap.password} onChange={(v) => updateImap(activePurpose, { password: v })} />
                        </div>
                    </section>

                    <Separator />

                    {/* POP */}
                    <section className="space-y-3">
                        <div className="flex items-center gap-2">
                            <Bell className="h-4 w-4" />
                            <h3 className="font-medium">POP</h3>
                        </div>
                        <div className="grid gap-3 md:grid-cols-3">
                            <LabeledInput label="Host" value={emailProfiles[activePurpose].pop.host} onChange={(v) => updatePop(activePurpose, { host: v })} />
                            <LabeledNumber label="Port" value={emailProfiles[activePurpose].pop.port} onChange={(v) => updatePop(activePurpose, { port: v })} />
                            <div className="flex items-center gap-6 mt-6">
                                <CheckToggle label="Use SSL" checked={emailProfiles[activePurpose].pop.useSSL} onChange={(v) => updatePop(activePurpose, { useSSL: v })} />
                            </div>
                            <LabeledInput label="Username" value={emailProfiles[activePurpose].pop.username} onChange={(v) => updatePop(activePurpose, { username: v })} />
                            <LabeledInput label="Password" type="password" value={emailProfiles[activePurpose].pop.password} onChange={(v) => updatePop(activePurpose, { password: v })} />
                        </div>
                    </section>

                    <div className="flex items-center justify-end gap-2">
                        <Button variant="outline" onClick={testConnections}>
                            <TestTube2 className="mr-2 h-4 w-4" />
                            Test connections
                        </Button>
                        <Button variant="success" onClick={saveEmailSettings}>
                            Save SMTP settings
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    );
}
