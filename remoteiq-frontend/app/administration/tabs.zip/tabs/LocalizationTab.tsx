"use client";

import * as React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { TabsContent } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { ToastFn, LocalizationSettings } from "../types";

interface LocalizationTabProps {
    push: ToastFn;
}

export default function LocalizationTab({ push }: LocalizationTabProps) {
    const [localization, setLocalization] = React.useState<LocalizationSettings>({
        language: "en-US",
        dateFormat: "MM/DD/YYYY",
        timeFormat: "12h",
        numberFormat: "1,234.56",
        timeZone: "America/New_York",
        firstDayOfWeek: "sunday",
    });

    return (
        <TabsContent value="localization" className="mt-0">
            <Card>
                <CardHeader>
                    <CardTitle>Localization & Regional Settings</CardTitle>
                    <CardDescription>Configure language, time zone, and formatting for dates and numbers.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid gap-3 md:grid-cols-3">
                        <div className="grid gap-1">
                            <Label className="text-sm">Default Language</Label>
                            <Select value={localization.language} onValueChange={(v: LocalizationSettings['language']) => setLocalization(l => ({ ...l, language: v }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="en-US">English (US)</SelectItem>
                                    <SelectItem value="en-GB">English (UK)</SelectItem>
                                    <SelectItem value="es-ES">Spanish</SelectItem>
                                    <SelectItem value="fr-FR">French</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid gap-1">
                            <Label className="text-sm">Time Zone</Label>
                            <Select value={localization.timeZone} onValueChange={v => setLocalization(l => ({ ...l, timeZone: v }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="America/New_York">Eastern Time (US & Canada)</SelectItem>
                                    <SelectItem value="America/Chicago">Central Time (US & Canada)</SelectItem>
                                    <SelectItem value="America/Los_Angeles">Pacific Time (US & Canada)</SelectItem>
                                    <SelectItem value="Europe/London">London (GMT)</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid gap-1">
                            <Label className="text-sm">First Day of Week</Label>
                            <Select value={localization.firstDayOfWeek} onValueChange={(v: LocalizationSettings['firstDayOfWeek']) => setLocalization(l => ({ ...l, firstDayOfWeek: v }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="sunday">Sunday</SelectItem>
                                    <SelectItem value="monday">Monday</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid gap-1">
                            <Label className="text-sm">Date Format</Label>
                            <Select value={localization.dateFormat} onValueChange={(v: LocalizationSettings['dateFormat']) => setLocalization(l => ({ ...l, dateFormat: v }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                                    <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                                    <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid gap-1">
                            <Label className="text-sm">Time Format</Label>
                            <Select value={localization.timeFormat} onValueChange={(v: LocalizationSettings['timeFormat']) => setLocalization(l => ({ ...l, timeFormat: v }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="12h">12-hour</SelectItem>
                                    <SelectItem value="24h">24-hour</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid gap-1">
                            <Label className="text-sm">Number Format</Label>
                            <Select value={localization.numberFormat} onValueChange={(v: LocalizationSettings['numberFormat']) => setLocalization(l => ({ ...l, numberFormat: v }))}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="1,234.56">1,234.56</SelectItem>
                                    <SelectItem value="1.234,56">1.234,56</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <div className="text-right">
                        <Button variant="success" onClick={() => push({ title: "Localization settings saved", kind: "success" })}>
                            Save Localization
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    );
}
