// app/administration/tabs/CompanyTab.tsx
"use client";

import * as React from "react";
import { Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LabeledInput } from "../helpers";
import { SettingCard } from "../helpers";
import { type ToastFn } from "../types";
import { getCompanyProfile, saveCompanyProfile, type CompanyProfile } from "@/lib/api";

export default function CompanyTab({ push }: { push: ToastFn }) {
    const [loading, setLoading] = React.useState(true);
    const [saving, setSaving] = React.useState(false);
    const [form, setForm] = React.useState<CompanyProfile>({
        name: "",
        legalName: "",
        email: "",
        phone: "",
        fax: "",
        website: "",
        vatTin: "",
        address1: "",
        address2: "",
        city: "",
        state: "",
        postal: "",
        country: "",
    });

    React.useEffect(() => {
        (async () => {
            try {
                const data = await getCompanyProfile();
                setForm((prev) => ({ ...prev, ...data }));
            } catch (e: any) {
                push({ title: "Failed to load company profile", desc: e?.message, kind: "destructive" });
            } finally {
                setLoading(false);
            }
        })();
    }, [push]);

    function set<K extends keyof CompanyProfile>(key: K, value: CompanyProfile[K]) {
        setForm((f) => ({ ...f, [key]: value }));
    }

    async function onSave() {
        setSaving(true);
        try {
            await saveCompanyProfile(form);
            push({ title: "Company profile saved", kind: "success" });
        } catch (e: any) {
            push({ title: "Save failed", desc: e?.message, kind: "destructive" });
        } finally {
            setSaving(false);
        }
    }

    if (loading) return null;

    return (
        <section id="company" className="space-y-4">
            <SettingCard
                icon={<Building2 className="h-5 w-5" />}
                title="Company profile"
                desc="Basic organization identity & contact details used across billing, emails, and the client portal."
            >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <LabeledInput label="Company Name *" value={form.name} onChange={(v) => set("name", v)} />
                    <LabeledInput label="Legal Name" value={form.legalName ?? ""} onChange={(v) => set("legalName", v)} />
                    <LabeledInput label="Email" value={form.email ?? ""} onChange={(v) => set("email", v)} />
                    <LabeledInput label="Phone" value={form.phone ?? ""} onChange={(v) => set("phone", v)} />
                    <LabeledInput label="Fax" value={form.fax ?? ""} onChange={(v) => set("fax", v)} />
                    <LabeledInput label="Website (https://...)" value={form.website ?? ""} onChange={(v) => set("website", v)} />
                    <LabeledInput label="VAT / TIN" value={form.vatTin ?? ""} onChange={(v) => set("vatTin", v)} />
                    <div />
                    <LabeledInput label="Address Line 1" value={form.address1 ?? ""} onChange={(v) => set("address1", v)} />
                    <LabeledInput label="Address Line 2" value={form.address2 ?? ""} onChange={(v) => set("address2", v)} />
                    <LabeledInput label="City" value={form.city ?? ""} onChange={(v) => set("city", v)} />
                    <LabeledInput label="State/Province" value={form.state ?? ""} onChange={(v) => set("state", v)} />
                    <LabeledInput label="Postal Code" value={form.postal ?? ""} onChange={(v) => set("postal", v)} />
                    <LabeledInput label="Country" value={form.country ?? ""} onChange={(v) => set("country", v)} />
                </div>

                <div className="mt-4 flex gap-2">
                    <Button onClick={onSave} disabled={saving || !form.name} variant="success">
                        {saving ? "Saving..." : "Save changes"}
                    </Button>
                </div>
            </SettingCard>
        </section>
    );
}
