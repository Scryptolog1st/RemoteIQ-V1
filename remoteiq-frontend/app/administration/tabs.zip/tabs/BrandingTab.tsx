"use client";

import * as React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { TabsContent } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Palette, Upload } from "lucide-react";
import { LabeledInput, LabeledTextarea, CheckToggle, SettingCard } from "../helpers";
import { ToastFn, BrandingSettings } from "../types";

interface BrandingTabProps {
    push: ToastFn;
}

export default function BrandingTab({ push }: BrandingTabProps) {
    const [branding, setBranding] = React.useState<BrandingSettings>({
        primaryColor: "#09090b",
        secondaryColor: "#fafafa",
        emailHeader: "<h1>{{org_name}}</h1>",
        emailFooter: "<p>Copyright 2025. All rights reserved.</p>",
        customCss: "/* Your custom CSS here */",
        allowClientThemeToggle: true,
    });

    return (
        <TabsContent value="branding" className="mt-0">
            <Card>
                <CardHeader>
                    <CardTitle>Branding & Appearance</CardTitle>
                    <CardDescription>Customize logos, colors, and other visual elements of the application.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <SettingCard icon={<Palette className="h-4 w-4" />} title="Colors" desc="Define primary and secondary colors.">
                            <div className="grid grid-cols-2 gap-4">
                                <LabeledInput label="Primary Color" type="color" value={branding.primaryColor} onChange={v => setBranding(b => ({ ...b, primaryColor: v }))} />
                                <LabeledInput label="Secondary Color" type="color" value={branding.secondaryColor} onChange={v => setBranding(b => ({ ...b, secondaryColor: v }))} />
                            </div>
                        </SettingCard>

                        <SettingCard icon={<Upload className="h-4 w-4" />} title="Logos & Favicon" desc="Upload your company logos for light/dark themes.">
                            <div className="space-y-3">
                                <div>
                                    <Label className="text-sm">Main Logo (for light backgrounds)</Label>
                                    <Input type="file" />
                                </div>
                                <div>
                                    <Label className="text-sm">Inverse Logo (for dark backgrounds)</Label>
                                    <Input type="file" />
                                </div>
                                <div>
                                    <Label className="text-sm">Favicon (.ico)</Label>
                                    <Input type="file" />
                                </div>
                            </div>
                        </SettingCard>
                    </div>

                    <Separator />

                    <LabeledTextarea label="Email Header HTML" value={branding.emailHeader} onChange={v => setBranding(b => ({ ...b, emailHeader: v }))} rows={5} />
                    <LabeledTextarea label="Email Footer HTML" value={branding.emailFooter} onChange={v => setBranding(b => ({ ...b, emailFooter: v }))} rows={5} />

                    <Separator />

                    <LabeledTextarea label="Custom CSS" value={branding.customCss} onChange={v => setBranding(b => ({ ...b, customCss: v }))} rows={10} />

                    <Separator />

                    <CheckToggle label="Allow clients to toggle light/dark theme in portal" checked={branding.allowClientThemeToggle} onChange={v => setBranding(b => ({ ...b, allowClientThemeToggle: v }))} />

                    <div className="text-right">
                        <Button variant="success" onClick={() => push({ title: "Branding settings saved", kind: "success" })}>
                            Save Branding
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    );
}
