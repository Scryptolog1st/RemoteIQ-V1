"use client";

import * as React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { TabsContent } from "@/components/ui/tabs";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { UserPlus, Trash2, Search, Lock, Shield } from "lucide-react";
import { Role, User, ToastFn } from "../types"; // We'll create this types file next

interface UsersTabProps {
    users: User[];
    setUsers: React.Dispatch<React.SetStateAction<User[]>>;
    roles: Role[];
    push: ToastFn;
    setRemoveUserId: (id: string | null) => void;
    setReset2FAUserId: (id: string | null) => void;
    setInviteOpen: (open: boolean) => void;
}

export default function UsersTab({
    users,
    setUsers,
    roles,
    push,
    setRemoveUserId,
    setReset2FAUserId,
    setInviteOpen,
}: UsersTabProps) {
    const [query, setQuery] = React.useState("");

    const filtered = users.filter(
        (u) => u.name.toLowerCase().includes(query.toLowerCase()) || u.email.toLowerCase().includes(query.toLowerCase())
    );

    return (
        <TabsContent value="users" className="mt-0">
            <Card>
                <CardHeader>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Invite, suspend and manage members.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="relative w-full sm:w-72">
                            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search users…" className="pl-8" />
                        </div>
                        <div className="flex items-center gap-2">
                            <Button variant="success" onClick={() => setInviteOpen(true)}>
                                <UserPlus className="mr-2 h-4 w-4" />
                                Invite user
                            </Button>
                        </div>
                    </div>

                    <div className="rounded-md border">
                        <div className="grid grid-cols-12 border-b bg-muted/30 p-2 text-xs font-medium text-muted-foreground">
                            <div className="col-span-3 px-2">Name</div>
                            <div className="col-span-3 px-2">Email</div>
                            <div className="col-span-2 px-2">Role</div>
                            <div className="col-span-4 px-2 text-right">Actions</div>
                        </div>
                        {filtered.map((u) => (
                            <div key={u.id} className="grid grid-cols-12 items-center border-b p-2 last:border-b-0">
                                <div className="col-span-3 px-2">{u.name}</div>
                                <div className="col-span-3 px-2 text-muted-foreground">{u.email}</div>
                                <div className="col-span-2 px-2 relative z-10">
                                    <Select
                                        value={u.role}
                                        onValueChange={(v) => {
                                            setUsers((prev) => prev.map((p) => (p.id === u.id ? { ...p, role: v } : p)));
                                            push({ title: "Role updated", kind: "success" });
                                        }}
                                    >
                                        <SelectTrigger className="h-8">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {roles.map((r) => (
                                                <SelectItem key={r.id} value={r.name}>
                                                    {r.name}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="col-span-4 px-2 flex items-center justify-end gap-2">
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => push({ title: "Password reset sent", kind: "success", desc: u.email })}
                                    >
                                        <Lock className="mr-2 h-4 w-4" />
                                        Reset
                                    </Button>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => setReset2FAUserId(u.id)}
                                        title="Invalidate current 2FA device and require re-enrollment"
                                    >
                                        <Shield className="mr-2 h-4 w-4" />
                                        Reset 2FA
                                    </Button>
                                    <Button variant="destructive" size="sm" onClick={() => setRemoveUserId(u.id)}>
                                        <Trash2 className="mr-2 h-4 w-4" />
                                        Remove
                                    </Button>
                                </div>
                            </div>
                        ))}
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    );
}
