"use client";

import * as React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TabsContent } from "@/components/ui/tabs";
import { LabeledInput } from "../helpers";

export type SupportTabProps = {
    push: (t: any) => void;
};

export default function SupportTab({ push }: SupportTabProps) {
    return (
        <TabsContent value="support">
            <Card>
                <CardHeader>
                    <CardTitle>Support & Legal</CardTitle>
                    <CardDescription>
                        Configure custom support links, legal documents, and versioning.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                        <LabeledInput label="Custom Support URL" value="https://support.example.com" onChange={() => { }} />
                        <LabeledInput label="System Status Page URL" value="https://status.example.com" onChange={() => { }} />
                        <LabeledInput label="Terms of Service URL" value="/legal/terms" onChange={() => { }} />
                        <LabeledInput label="Privacy Policy URL" value="/legal/privacy" onChange={() => { }} />
                    </div>
                    <div className="text-right">
                        <Button variant="success" onClick={() => push({ title: "Support & Legal settings saved", kind: "success" })}>
                            Save Settings
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    );
}
