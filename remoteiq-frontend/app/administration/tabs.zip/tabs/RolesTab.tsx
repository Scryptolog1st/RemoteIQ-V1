// app/administration/tabs/RolesTab.tsx
"use client";

import * as React from "react";
import { TabsContent } from "@/components/ui/tabs";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { PermRow } from "../helpers";
import { Role, PermissionKey, ToastFn } from "../types";

type Props = {
    roles: Role[];
    setRoles: React.Dispatch<React.SetStateAction<Role[]>>;
    push: ToastFn;
    setDeleteRoleId: (id: string) => void;
};

export default function RolesTab({ roles, setRoles, push, setDeleteRoleId }: Props) {
    const [selectedId, setSelectedId] = React.useState<string>(roles[0]?.id ?? "");
    const selectedRole = React.useMemo(() => roles.find(r => r.id === selectedId) ?? roles[0], [roles, selectedId]);

    function renameSelected(name: string) {
        if (!selectedRole) return;
        setRoles(prev => prev.map(r => (r.id === selectedRole.id ? { ...r, name } : r)));
    }

    function togglePerm(roleId: string, key: PermissionKey) {
        setRoles(prev =>
            prev.map(r =>
                r.id === roleId ? { ...r, permissions: { ...r.permissions, [key]: !r.permissions[key] } } : r
            )
        );
    }

    function addRole() {
        const id = `r-${Math.random().toString(36).slice(2, 8)}`;
        const base = selectedRole?.permissions ?? {
            view_devices: true,
            manage_devices: false,
            manage_users: false,
            billing_access: false,
            view_audit: true,
            manage_api: false,
            manage_flags: false,
        };
        const newRole: Role = {
            id,
            name: "New Role",
            permissions: { ...base },
        };
        setRoles(prev => [newRole, ...prev]);
        setSelectedId(id);
        push({ title: "Role created", kind: "success" });
    }

    function saveRole() {
        // no backend yet; just toast
        push({ title: "Role saved", kind: "success" });
    }

    function deleteRole() {
        if (!selectedRole) return;
        setDeleteRoleId(selectedRole.id);
    }

    if (!selectedRole) {
        return (
            <TabsContent value="roles" className="mt-0">
                <Card>
                    <CardHeader>
                        <CardTitle>Roles</CardTitle>
                        <CardDescription>Define permissions and access levels for your team.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={addRole}>Add Role</Button>
                    </CardContent>
                </Card>
            </TabsContent>
        );
    }

    return (
        <TabsContent value="roles" className="mt-0">
            <Card>
                <CardHeader className="flex flex-col gap-2">
                    <div className="flex items-center justify-between">
                        <div>
                            <CardTitle>Roles</CardTitle>
                            <CardDescription>Define permissions and access levels for your team.</CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                            <Button variant="outline" onClick={addRole}>Add Role</Button>
                            <Button variant="destructive" onClick={deleteRole} disabled={!!selectedRole.builtIn}>
                                Delete Role
                            </Button>
                            <Button variant="success" onClick={saveRole}>Save</Button>
                        </div>
                    </div>
                </CardHeader>

                <CardContent className="space-y-6">
                    {/* Role selector */}
                    <div className="grid gap-3 md:grid-cols-2">
                        <div className="grid gap-1">
                            <Label className="text-sm">Select Role</Label>
                            <Select value={selectedRole.id} onValueChange={setSelectedId}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    {roles.map(r => (
                                        <SelectItem key={r.id} value={r.id}>
                                            {r.name}{r.builtIn ? " (built-in)" : ""}
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="grid gap-1">
                            <Label className="text-sm">Role Name</Label>
                            <Input
                                value={selectedRole.name}
                                onChange={(e) => renameSelected(e.target.value)}
                                disabled={!!selectedRole.builtIn}
                            />
                        </div>
                    </div>

                    {/* Permissions matrix */}
                    <div className="rounded-md border p-4 space-y-3">
                        <div className="font-medium mb-1">Permissions</div>

                        <PermRow label="View devices" hint="Allows read-only access to device inventory and details.">
                            <Switch
                                checked={selectedRole.permissions.view_devices}
                                onCheckedChange={() => togglePerm(selectedRole.id, "view_devices")}
                            />
                        </PermRow>

                        <PermRow label="Manage devices" hint="Allows actions like reboot, patch, and agent tasks.">
                            <Switch
                                checked={selectedRole.permissions.manage_devices}
                                onCheckedChange={() => togglePerm(selectedRole.id, "manage_devices")}
                            />
                        </PermRow>

                        <PermRow label="Manage users" hint="Create, update, or delete users and assign roles.">
                            <Switch
                                checked={selectedRole.permissions.manage_users}
                                onCheckedChange={() => togglePerm(selectedRole.id, "manage_users")}
                            />
                        </PermRow>

                        <PermRow label="Billing access" hint="Access to subscription, invoices, and payment methods.">
                            <Switch
                                checked={selectedRole.permissions.billing_access}
                                onCheckedChange={() => togglePerm(selectedRole.id, "billing_access")}
                            />
                        </PermRow>

                        <PermRow label="View audit logs" hint="Read-only access to system audit trail.">
                            <Switch
                                checked={selectedRole.permissions.view_audit}
                                onCheckedChange={() => togglePerm(selectedRole.id, "view_audit")}
                            />
                        </PermRow>

                        <PermRow label="Manage API keys" hint="Create and revoke API keys, set scopes.">
                            <Switch
                                checked={selectedRole.permissions.manage_api}
                                onCheckedChange={() => togglePerm(selectedRole.id, "manage_api")}
                            />
                        </PermRow>

                        <PermRow label="Manage feature flags" hint="Toggle experimental and rollout flags.">
                            <Switch
                                checked={selectedRole.permissions.manage_flags}
                                onCheckedChange={() => togglePerm(selectedRole.id, "manage_flags")}
                            />
                        </PermRow>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
    );
}
