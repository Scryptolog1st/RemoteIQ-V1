import { Module } from "@nestjs/common";
import { AuthModule } from "./auth/auth.module";
import { WsModule } from "./ws/ws.module";
import { AgentsModule } from "./agents/agents.module";
import { JobsModule } from "./jobs/jobs.module";
import { CommonModule } from "./common/common.module";

@Module({
    imports: [CommonModule, AuthModule, WsModule, AgentsModule, JobsModule],
})
export class AppModule { }
