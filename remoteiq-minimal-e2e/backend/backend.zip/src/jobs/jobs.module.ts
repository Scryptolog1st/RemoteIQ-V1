import { Module, forwardRef } from "@nestjs/common";
import { JobsService } from "./jobs.service";
import { DispatcherService } from "./dispatcher.service";
import { JobsController } from "./jobs.controller";
import { DatabaseModule } from "../database/database.module";
import { CommonModule } from "../common/common.module";

@Module({
  imports: [DatabaseModule, CommonModule, forwardRef(() => JobsModule)],
  controllers: [JobsController],
  providers: [JobsService, DispatcherService],
  exports: [JobsService, DispatcherService],
})
export class JobsModule { }
