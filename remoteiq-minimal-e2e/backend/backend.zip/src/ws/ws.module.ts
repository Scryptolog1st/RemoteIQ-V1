// backend/src/ws/ws.module.ts
import { Module } from '@nestjs/common';
import { AgentGateway } from './agent.gateway';
import { DatabaseModule } from '../database/database.module';
import { JobsModule } from '../jobs/jobs.module';
import { CommonModule } from '../common/common.module';

@Module({
  // DatabaseModule must export PrismaService (done in database.module.ts)
  imports: [DatabaseModule, CommonModule, JobsModule],
  providers: [AgentGateway],
  exports: [AgentGateway],
})
export class WsModule { }
