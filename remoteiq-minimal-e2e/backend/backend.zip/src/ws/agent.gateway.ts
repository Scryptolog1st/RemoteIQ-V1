// backend/src/ws/agent.gateway.ts
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Logger } from '@nestjs/common';
import { Server, WebSocket, RawData } from 'ws';
import { IncomingMessage } from 'http';
import { createHash } from 'crypto';
import { PrismaService } from '../database/prisma.service';

interface AgentSocket extends WebSocket {
  agentId?: string; // Prisma schema uses String ids
}

interface AgentMessage {
  event?: string;              // 'heartbeat' | 'hello' | ...
  type?: string;               // 'heartbeat' | 'hello' | 'agent.hello'
  data?: { agentId?: string }; // Nest-style payload
  agentId?: string;            // flat style
}

@WebSocketGateway({ path: '/ws/agent' })
export class AgentGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer()
  public server!: Server; // definite assignment

  private readonly logger = new Logger(AgentGateway.name);

  constructor(private readonly prisma: PrismaService) { }

  async handleConnection(socket: AgentSocket, request: IncomingMessage) {
    const ip =
      (request.headers['x-forwarded-for'] as string) ||
      request.socket.remoteAddress;
    this.logger.log(`New agent connection from ${ip}`);

    // --- Extract token from Authorization or query ---
    let token: string | null = null;
    const auth = request.headers.authorization;
    if (auth?.startsWith('Bearer ')) token = auth.substring(7);
    if (!token) {
      const url = new URL(request.url ?? '/', `http://${request.headers.host}`);
      token = url.searchParams.get('token');
    }
    if (!token) {
      this.logger.warn('Rejected: no token provided');
      socket.close(1008, 'Token not provided');
      return;
    }

    try {
      const tokenHash = createHash('sha256').update(token).digest('hex');

      // tokenHash is @unique in your Prisma schema
      const agent = await this.prisma.agent.findUnique({ where: { tokenHash } });
      if (!agent) {
        this.logger.warn(`Rejected: invalid token (hash ${tokenHash})`);
        socket.close(1008, 'Invalid token');
        return;
      }

      socket.agentId = agent.id;

      // mark presence immediately
      const boot = await this.prisma.agent.update({
        where: { id: agent.id },
        data: { lastHeartbeatAt: new Date() },
        select: { id: true, lastHeartbeatAt: true },
      });
      this.logger.log(
        `Initial presence for ${boot.id} -> ${boot.lastHeartbeatAt.toISOString()}`,
      );

      this.logger.log(`Agent ${agent.id} authenticated and connected.`);
    } catch (err: any) {
      this.logger.error(
        'Auth/initial heartbeat failed',
        err?.stack ?? String(err),
      );
      socket.close(1011, 'Internal server error');
      return;
    }

    // Listen for messages
    socket.on('message', (raw: RawData) =>
      this.handleIncomingMessage(socket, raw),
    );
  }

  private async handleIncomingMessage(socket: AgentSocket, raw: RawData) {
    const text = raw.toString('utf8');
    let msg: AgentMessage | null = null;

    try {
      msg = JSON.parse(text) as AgentMessage;
    } catch {
      this.logger.warn(
        `Non-JSON message from ${socket.agentId ?? 'unknown'}: ${text.slice(
          0,
          200,
        )}`,
      );
      return;
    }
    if (!msg) return;

    // Debug what we actually received
    this.logger.debug(
      `WS message from ${socket.agentId ?? 'unauth'}: ${text.slice(0, 500)}`,
    );

    const kind = msg.event ?? msg.type;

    switch (kind) {
      case 'hello':
      case 'agent.hello': {
        const helloId = msg.agentId ?? msg.data?.agentId;
        if (helloId && !socket.agentId) {
          socket.agentId = helloId;
          this.logger.log(
            `Agent session associated via "hello": ${socket.agentId}`,
          );
        }
        break;
      }

      case 'heartbeat': {
        if (!socket.agentId) {
          this.logger.warn('Heartbeat from unauthenticated socket; ignoring');
          return;
        }
        try {
          const updated = await this.prisma.agent.update({
            where: { id: socket.agentId },
            data: { lastHeartbeatAt: new Date() },
            select: { id: true, lastHeartbeatAt: true },
          });
          this.logger.log(
            `Heartbeat persisted for ${updated.id} -> ${updated.lastHeartbeatAt.toISOString()}`,
          );
          socket.send(
            JSON.stringify({ event: 'ack', data: { kind: 'heartbeat' } }),
          );
        } catch (err: any) {
          this.logger.error(
            `Failed updating lastHeartbeatAt for ${socket.agentId}`,
            err?.stack ?? String(err),
          );
        }
        break;
      }

      default:
        this.logger.debug(
          `Unknown message type "${kind}" from ${socket.agentId
          }: ${text.slice(0, 200)}`,
        );
        break;
    }
  }

  handleDisconnect(socket: AgentSocket) {
    if (socket.agentId)
      this.logger.log(`Agent ${socket.agentId} disconnected`);
    else this.logger.log('Unauthenticated socket disconnected');
  }
}
