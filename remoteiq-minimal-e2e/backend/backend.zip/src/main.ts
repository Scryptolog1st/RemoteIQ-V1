import 'reflect-metadata'; // ✅ must be first
import 'dotenv/config';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import cookieParser from 'cookie-parser';
import { WsAdapter } from '@nestjs/platform-ws';
import { ValidationPipe } from '@nestjs/common'; // ✅

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.use(cookieParser());
  app.enableCors();
  app.useWebSocketAdapter(new WsAdapter(app));

  // ✅ run class-validator on all DTOs
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,           // strips unknown props
    forbidNonWhitelisted: true,// 400 if unknown props present
    transform: true,           // auto-transform primitives (e.g. strings to numbers)
  }));

  // optional: tidy shutdown hooks (SIGINT/SIGTERM)
  app.enableShutdownHooks();

  // simple health check
  app.getHttpAdapter()
    .getInstance()
    .get('/healthz', (_req: any, res: any) => res.send('OK'));

  const port = Number(process.env.PORT || 3001);
  await app.listen(port);
  console.log(`RemoteIQ backend listening on http://localhost:${port}`);
}
bootstrap();
