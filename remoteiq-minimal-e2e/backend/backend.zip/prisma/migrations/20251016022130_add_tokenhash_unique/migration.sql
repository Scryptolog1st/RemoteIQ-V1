-- DropIndex
DROP INDEX "Agent_tokenHash_idx";
