import { IsBoolean, IsEmail, IsIn, IsInt, IsOptional, IsString, IsUUID, Min } from "class-validator";
import { Type } from "class-transformer";

export type UserRow = {
    id: string;
    name: string;
    email: string;
    role: string;
    status: "active" | "suspended";
    twoFactorEnabled: boolean;
    lastSeen: string | null;
    createdAt: string;
    updatedAt: string;
};

export class ListUsersQuery {
    @IsOptional() @IsString() q?: string;

    @IsOptional() @IsString() role?: string;

    @IsOptional() @IsIn(["all", "active", "suspended"])
    status: "all" | "active" | "suspended" = "all";

    @IsOptional() @IsIn(["name", "email", "role", "lastSeen"])
    sortKey: "name" | "email" | "role" | "lastSeen" = "name";

    @IsOptional() @IsIn(["asc", "desc"])
    sortDir: "asc" | "desc" = "asc";

    @IsOptional() @Type(() => Number) @IsInt() @Min(1)
    page: number = 1;

    @IsOptional() @Type(() => Number) @IsInt() @Min(1)
    pageSize: number = 25;
}

export class InviteUserDto {
    @IsOptional() @IsString() name?: string;

    @IsEmail() email!: string;

    @IsOptional() @IsString() role?: string;

    @IsOptional() @IsString() message?: string;
}

export class BulkInviteDto {
    invites!: InviteUserDto[];
}

export class UpdateRoleDto {
    @IsString() role!: string;
}

export class IdParam {
    @IsUUID() id!: string;
}

export class SuspendDto {
    @IsBoolean() suspended!: boolean;
}
