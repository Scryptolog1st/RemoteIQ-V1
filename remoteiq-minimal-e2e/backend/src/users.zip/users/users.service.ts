import { Injectable, NotFoundException } from "@nestjs/common";
import { PgPoolService } from "../storage/pg-pool.service";
import { BulkInviteDto, InviteUserDto, ListUsersQuery, UpdateRoleDto, UserRow } from "./users.dto";

function mapUserRow(r: any): UserRow {
    return {
        id: r.id,
        name: r.name,
        email: r.email,
        role: r.role,
        status: r.status,
        twoFactorEnabled: r.two_factor_enabled,
        lastSeen: r.last_seen ? new Date(r.last_seen).toISOString() : null,
        createdAt: new Date(r.created_at).toISOString(),
        updatedAt: new Date(r.updated_at).toISOString(),
    };
}

@Injectable()
export class UsersService {
    constructor(private readonly pg: PgPoolService) { }

    async list(q: ListUsersQuery): Promise<{ items: UserRow[]; total: number }> {
        const params: any[] = [];
        const where: string[] = [];

        if (q.q) {
            params.push(`%${q.q.toLowerCase()}%`);
            where.push(`(LOWER(name) LIKE $${params.length} OR LOWER(email) LIKE $${params.length})`);
        }

        if (q.role && q.role !== "all") {
            params.push(q.role);
            where.push(`role = $${params.length}`);
        }

        if (q.status && q.status !== "all") {
            params.push(q.status);
            where.push(`status = $${params.length}`);
        }

        const whereSql = where.length ? `WHERE ${where.join(" AND ")}` : "";

        const sortKeyMap: Record<string, string> = {
            name: "name",
            email: "email",
            role: "role",
            lastSeen: "last_seen",
        };
        const sortCol = sortKeyMap[q.sortKey] ?? "name";
        const sortDir = q.sortDir?.toUpperCase() === "DESC" ? "DESC" : "ASC";

        const page = Math.max(1, q.page ?? 1);
        const pageSize = Math.max(1, q.pageSize ?? 25);
        const offset = (page - 1) * pageSize;

        const countSql = `SELECT COUNT(*) AS c FROM users ${whereSql}`;
        const { rows: countRows } = await this.pg.query(countSql, params);
        const total = Number(countRows[0]?.c ?? 0);

        const dataSql = `
      SELECT
        id, name, email, role, status,
        two_factor_enabled, last_seen, created_at, updated_at
      FROM users
      ${whereSql}
      ORDER BY ${sortCol} ${sortDir}, name ASC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `;
        const { rows } = await this.pg.query(dataSql, [...params, pageSize, offset]);
        return { items: rows.map(mapUserRow), total };
    }

    async roles(): Promise<{ id: string; name: string; description: string | null }[]> {
        const { rows } = await this.pg.query(`SELECT id, name, description FROM roles ORDER BY name ASC`);
        return rows;
    }

    async inviteOne(dto: InviteUserDto): Promise<{ id: string }> {
        // Create user record in "active" status (adjust to "pending" if you prefer)
        const name = dto.name?.trim() || dto.email.split("@")[0];
        const role = dto.role?.trim() || "User";

        const { rows } = await this.pg.query(
            `INSERT INTO users (name, email, role, status)
       VALUES ($1, $2, $3, 'active')
       ON CONFLICT (email) DO NOTHING
       RETURNING id`,
            [name, dto.email, role],
        );

        const id = rows[0]?.id ?? "";
        // TODO: send invite email (out of scope here)
        return { id };
    }

    async inviteBulk(dto: BulkInviteDto): Promise<{ created: number }> {
        let created = 0;
        for (const inv of dto.invites || []) {
            const res = await this.inviteOne(inv);
            if (res.id) created++;
        }
        return { created };
    }

    async updateRole(id: string, dto: UpdateRoleDto): Promise<void> {
        // Use RETURNING so we can check rows.length (rowCount isn't typed)
        const { rows } = await this.pg.query(
            `UPDATE users SET role = $2, updated_at = NOW() WHERE id = $1 RETURNING id`,
            [id, dto.role],
        );
        if (rows.length === 0) throw new NotFoundException("User not found");
    }

    async setSuspended(id: string, suspended: boolean): Promise<void> {
        const status = suspended ? "suspended" : "active";
        const { rows } = await this.pg.query(
            `UPDATE users SET status = $2, updated_at = NOW() WHERE id = $1 RETURNING id`,
            [id, status],
        );
        if (rows.length === 0) throw new NotFoundException("User not found");
    }

    async reset2fa(id: string): Promise<void> {
        const { rows } = await this.pg.query(
            `UPDATE users SET two_factor_enabled = FALSE, updated_at = NOW() WHERE id = $1 RETURNING id`,
            [id],
        );
        if (rows.length === 0) throw new NotFoundException("User not found");
    }

    async remove(id: string): Promise<void> {
        const { rows } = await this.pg.query(
            `DELETE FROM users WHERE id = $1 RETURNING id`,
            [id],
        );
        if (rows.length === 0) throw new NotFoundException("User not found");
    }
}
